package com.example.videoconferrencingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import me.dm7.barcodescanner.zbar.Result;
import me.dm7.barcodescanner.zbar.ZBarScannerView;

public class ScanActivity extends AppCompatActivity implements ZBarScannerView.ResultHandler{

    private ZBarScannerView mScannerView;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        mScannerView = new ZBarScannerView(this);    // Programmatically initialize the scanner view
        setContentView(mScannerView);
    }

    @Override
    protected void onResume () {
        super.onResume ();

        mScannerView.setResultHandler(ScanActivity.this); // Register ourselves as a handler for scan results.
        mScannerView.startCamera();
    }

    @Override
    protected void onPause () {
        super.onPause ();
        mScannerView.stopCamera();
    }

    @Override
    public void handleResult (Result result) {
        Log.v("message", result.getContents()); // Prints scan results
        Log.v("message", result.getBarcodeFormat().getName()); // Prints the scan format (qrcode, pdf417 etc.)
        String visit_user_id=result.getContents ();
        FirebaseDatabase.getInstance ().getReference ().child ("Users").child (visit_user_id).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ()){
                    Contacts contacts=snapshot.getValue (Contacts.class);
                    Intent intent=new Intent(ScanActivity.this,ProfileActivity.class);
                    intent.putExtra("visit_user_id",visit_user_id);
                    intent.putExtra("profile_image",contacts.getImage());
                    intent.putExtra("user_name",contacts.getName());
                    startActivity(intent);
                    finish ();
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
        //ViewProfileActivity.tvresult.setText(result.getContents());
        onBackPressed();
        // If you would like to resume scanning, call this method below:
        //mScannerView.resumeCameraPreview(this);
    }
}