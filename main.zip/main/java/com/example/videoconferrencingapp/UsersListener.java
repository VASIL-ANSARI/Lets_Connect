package com.example.videoconferrencingapp;

public interface UsersListener {

    void initiateVideoMeeting(Contacts user);

    void initiateAudioMeeting(Contacts user);

    void onMultipleUserAction(Boolean b);
}
