package com.example.videoconferrencingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentUris;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class ProfileActivity extends AppCompatActivity {

    private String receiverUserID="",receiverUserImage="",receiverUserName="";
    private ImageView background_profile_view;
    private TextView name_profile;
    private Button add_friend;
    private Button decline_friend;
    DatabaseReference databaseReference,requestRef,friendRef;
    FirebaseUser firebaseUser;
    String CurrentState=Constants.NOTHING_HAPPEN;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        receiverUserID=getIntent().getExtras().get("visit_user_id").toString();
        receiverUserImage=getIntent().getExtras().get("profile_image").toString();
        receiverUserName=getIntent().getExtras().get("user_name").toString();

        background_profile_view=findViewById(R.id.background_profile_view);
        name_profile=findViewById(R.id.name_profile);
        add_friend=findViewById(R.id.add_friend);
        decline_friend=findViewById(R.id.decline_friend_request);

        Picasso.get().load(receiverUserImage).into(background_profile_view);
        name_profile.setText(receiverUserName);

        requestRef= FirebaseDatabase.getInstance().getReference().child("Requests");
        friendRef=FirebaseDatabase.getInstance ().getReference ().child ("friends");
       // databaseReference.keepSynced(true);
        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        if(receiverUserID.equals (firebaseUser.getUid ()))
        {
            add_friend.setVisibility (View.GONE);
            decline_friend.setVisibility (View.GONE);
        }
        else{
            CheckUserExistence(receiverUserID);
        }


        add_friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFriend(firebaseUser.getUid(),receiverUserID);
            }
        });
        decline_friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteFriend(firebaseUser.getUid(),receiverUserID);
            }
        });


    }

    private void CheckUserExistence (String userId) {
        friendRef.child (firebaseUser.getUid ()).child (userId).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ())
                {
                    CurrentState=Constants.STATUS_FRIEND;
                    add_friend.setVisibility (View.GONE);
                    decline_friend.setText ("UnFriend");
                    decline_friend.setVisibility (View.VISIBLE);
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
        friendRef.child (userId).child (firebaseUser.getUid ()).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ()){
                    CurrentState=Constants.STATUS_FRIEND;
                    add_friend.setVisibility (View.GONE);
                    decline_friend.setText ("UnFriend");
                    decline_friend.setVisibility (View.VISIBLE);
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
        requestRef.child (firebaseUser.getUid ()).child (userId).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ())
                {
                    if(snapshot.child ("status").getValue ().toString ().equals (Constants.STATUS_PENDING))
                    {
                        CurrentState=Constants.STATUS_SENT_PENDING;
                        add_friend.setText ("Cancel Friend Request");
                        add_friend.setVisibility (View.VISIBLE);
                        decline_friend.setVisibility (View.GONE);
                    }
//                    if(snapshot.child ("status").getValue ().toString ().equals (Constants.STATUS_DECLINE))
//                    {
//                        CurrentState=Constants.STATUS_SENT_DECLINE;
//                        add_friend.setText ("Add Friend");
//                        add_friend.setVisibility (View.VISIBLE);
//                        decline_friend.setVisibility (View.GONE);
//                    }
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });

        requestRef.child (userId).child (firebaseUser.getUid ()).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ())
                {
                    if(snapshot.child ("status").getValue ().toString ().equals (Constants.STATUS_PENDING))
                    {
                        CurrentState=Constants.SENT_PENDING;
                        add_friend.setText ("Accept Friend Request");
                        add_friend.setVisibility (View.VISIBLE);
                        decline_friend.setText ("Decline Friend Request");
                        decline_friend.setVisibility (View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });

        if(CurrentState.equals (Constants.NOTHING_HAPPEN)){
            CurrentState=Constants.NOTHING_HAPPEN;
            decline_friend.setVisibility (View.GONE);
        }
    }

    private void addFriend(String sender,String receiver)
    {
        Log.d("message add friend",sender+" "+receiver);
        if(CurrentState.equals (Constants.NOTHING_HAPPEN))
        {
            HashMap hashMap=new HashMap ();
            hashMap.put("status",Constants.STATUS_PENDING);
            hashMap.put("uid",receiver);
            requestRef.child (sender).child (receiver).updateChildren (hashMap).addOnCompleteListener (new OnCompleteListener () {
                @Override
                public void onComplete (@NonNull Task task) {
                    if(task.isSuccessful ())
                    {
                        HashMap hashMap1=new HashMap ();
                        hashMap1.put("status",Constants.STATUS_SENT_PENDING);
                        hashMap1.put("uid",sender);
                        requestRef.child (receiver).child (sender).updateChildren (hashMap1).addOnCompleteListener (new OnCompleteListener () {
                            @Override
                            public void onComplete (@NonNull Task task) {
                                Toast.makeText (ProfileActivity.this,"You have sent friend request",Toast.LENGTH_SHORT).show ();
                                decline_friend.setVisibility (View.GONE);
                                CurrentState=Constants.STATUS_SENT_PENDING;
                                add_friend.setText ("Cancel Friend Request");
                                add_friend.setVisibility (View.VISIBLE);
                            }
                        });

                    }
                    else{
                        Toast.makeText (ProfileActivity.this,"Error while sending request",Toast.LENGTH_SHORT).show ();
                    }
                }
            });
        }
        else if(CurrentState.equals (Constants.STATUS_SENT_PENDING) || CurrentState.equals (Constants.STATUS_SENT_DECLINE))
        {
            requestRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                @Override
                public void onComplete (@NonNull Task<Void> task) {
                    if(task.isSuccessful ())
                    {
                        requestRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                            @Override
                            public void onComplete (@NonNull Task<Void> task) {
                                Toast.makeText (ProfileActivity.this,"You have cancelled friend request",Toast.LENGTH_SHORT).show ();
                                CurrentState=Constants.NOTHING_HAPPEN;
                                add_friend.setText ("Add Friend");
                                add_friend.setVisibility (View.VISIBLE);
                                decline_friend.setVisibility (View.GONE);
                            }
                        });
                    }
                    else{
                        Toast.makeText (ProfileActivity.this,"Error while declining request",Toast.LENGTH_SHORT).show ();
                    }
                }
            });
        }
        else if(CurrentState.equals (Constants.SENT_PENDING)){
            requestRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                @Override
                public void onComplete (@NonNull Task<Void> task) {
                    if(task.isSuccessful ()){

                        requestRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                            @Override
                            public void onComplete (@NonNull Task<Void> task) {
                                HashMap hashMap=new HashMap ();
                                hashMap.put ("status",Constants.STATUS_FRIEND);
                                hashMap.put ("uid",receiverUserID);
                                friendRef.child (firebaseUser.getUid ()).child (receiver).updateChildren (hashMap)
                                        .addOnCompleteListener (new OnCompleteListener () {
                                            @Override
                                            public void onComplete (@NonNull Task task) {
                                                if(task.isSuccessful ())
                                                {
                                                    HashMap hashMap1=new HashMap ();
                                                    hashMap1.put ("status",Constants.STATUS_FRIEND);
                                                    hashMap1.put ("uid",firebaseUser.getUid ());
                                                    friendRef.child (receiver).child (firebaseUser.getUid ()).updateChildren (hashMap1)
                                                            .addOnCompleteListener (new OnCompleteListener () {
                                                                @Override
                                                                public void onComplete (@NonNull Task task) {
                                                                    Toast.makeText (ProfileActivity.this,"You added a new Friend",Toast.LENGTH_SHORT).show ();
                                                                    CurrentState=Constants.STATUS_FRIEND;
                                                                    add_friend.setVisibility (View.GONE);
                                                                    decline_friend.setText ("UnFriend");
                                                                    decline_friend.setVisibility (View.VISIBLE);
                                                                }
                                                            });
                                                }
                                            }
                                        });
                            }
                        });
                    }
                }
            });
        }
        else if(CurrentState.equals (Constants.STATUS_FRIEND))
        {
            //TODO -complete code here
        }

    }

    private void deleteFriend(String sender,String receiver)
    {
        Log.d("message delete friend",sender+" "+receiver);
        if(CurrentState.equals (Constants.STATUS_FRIEND))
        {
            friendRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                @Override
                public void onComplete (@NonNull Task<Void> task) {
                    if(task.isSuccessful ())
                    {
                        friendRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                            @Override
                            public void onComplete (@NonNull Task<Void> task) {
                                if(task.isSuccessful ())
                                {
                                    Toast.makeText (ProfileActivity.this,"You are no longer friends now",Toast.LENGTH_SHORT).show ();
                                    CurrentState=Constants.NOTHING_HAPPEN;
                                    add_friend.setText ("Add Friend");
                                    add_friend.setVisibility (View.VISIBLE);
                                    decline_friend.setVisibility (View.GONE);
                                }
                            }
                        });
                    }
                }
            });
        }
        else if(CurrentState.equals (Constants.SENT_PENDING)){
//            HashMap hashMap=new HashMap ();
//            hashMap.put("status",Constants.STATUS_DECLINE);
            requestRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener () {
                @Override
                public void onComplete (@NonNull Task task) {
                    if(task.isSuccessful ())
                    {
                        requestRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                            @Override
                            public void onComplete (@NonNull Task<Void> task) {
                                Toast.makeText (ProfileActivity.this,"You have declined Friend Request",Toast.LENGTH_SHORT).show ();
                                CurrentState=Constants.NOTHING_HAPPEN;
                                add_friend.setText ("Add Friend");
                                add_friend.setVisibility (View.VISIBLE);
                                decline_friend.setVisibility (View.GONE);
                            }
                        });
                    }
                }
            });
        }
    }

}