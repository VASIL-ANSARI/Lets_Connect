package com.example.videoconferrencingapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.videoconferrencingapp.databinding.DeleteDialogBinding;
import com.github.pgreze.reactions.ReactionPopup;
import com.github.pgreze.reactions.ReactionsConfig;
import com.github.pgreze.reactions.ReactionsConfigBuilder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter {
    private Context mContext;
    private List<Chat> mChat;
    private String imagurl;

    final int ITEM_SENT = 1;
    final int ITEM_RECEIVE = 2;

    String senderRoom;
    String receiverRoom;

    FirebaseUser fUser;

    public MessageAdapter (Context mContext, List<Chat> mChat, String imagurl, String senderRoom, String receiverRoom) {
        this.mContext = mContext;
        this.mChat = mChat;
        this.imagurl = imagurl;
        this.senderRoom = senderRoom;
        this.receiverRoom = receiverRoom;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder (@NonNull ViewGroup parent, int viewType) {
        if (viewType == ITEM_SENT) {
            Log.d ("message", "right message");
            View view = LayoutInflater.from (mContext).inflate (R.layout.chat_item_right, parent, false);
            return new SentViewHolder (view);
        } else {
            Log.d ("message", "left message");
            View view = LayoutInflater.from (mContext).inflate (R.layout.chat_item_left, parent, false);
            return new ReceiverViewHolder (view);
        }
    }

    @Override
    public int getItemViewType (int position) {
        Chat message = mChat.get (position);
        if (FirebaseAuth.getInstance ().getUid ().equals (message.getSenderId ())) {
            return ITEM_SENT;
        } else {
            return ITEM_RECEIVE;
        }
    }

    @Override
    public void onBindViewHolder (@NonNull RecyclerView.ViewHolder holder, int position) {

        Chat message = mChat.get (position);

        if(holder.getClass ()==ReceiverViewHolder.class){
            ReceiverViewHolder viewHolder=(ReceiverViewHolder)holder;
            if(message.getMessageType ().equals ("text") || message.getMessageType ().equals ("removed")) {
                viewHolder.show_message.setVisibility (View.VISIBLE);
                viewHolder.show_message.setText (message.getMessage ());
                viewHolder.imageMessage.setVisibility (View.GONE);
                viewHolder.videoLayoutChat.setVisibility (View.GONE);
                viewHolder.pdfChatMessage.setVisibility (View.GONE);
            }
            else if(message.getMessageType ().equals ("image")){
                viewHolder.show_message.setVisibility (View.GONE);
                Picasso.get ().load (message.getMessage()).into (viewHolder.imageMessage);
                viewHolder.imageMessage.setVisibility (View.VISIBLE);
                viewHolder.videoLayoutChat.setVisibility (View.GONE);
                viewHolder.pdfChatMessage.setVisibility (View.GONE);
            }
            else if(message.getMessageType ().equals ("video")){
                viewHolder.show_message.setVisibility (View.GONE);
                viewHolder.imageMessage.setVisibility (View.GONE);
                viewHolder.videoLayoutChat.setVisibility (View.VISIBLE);
                viewHolder.pdfChatMessage.setVisibility (View.GONE);
                //viewHolder.videoMessage.setVideoURI (Uri.parse (message.getMessage ()));
            }
            else if(message.getMessageType ().equals ("pdf")){
                viewHolder.show_message.setVisibility (View.GONE);
                viewHolder.imageMessage.setVisibility (View.GONE);
                viewHolder.videoLayoutChat.setVisibility (View.GONE);
                viewHolder.pdfChatMessage.setVisibility (View.VISIBLE);
            }
            if(imagurl.equals ("default")){
                ((ReceiverViewHolder) holder).profile_image.setImageResource (R.drawable.profile_image);
            }else{
                if(((ReceiverViewHolder) holder).profile_image!=null)
                    Picasso.get ().load (imagurl).into (((ReceiverViewHolder) holder).profile_image);
            }
        }
        else{
            SentViewHolder viewHolder=(SentViewHolder)holder;
            if(message.getMessageType ().equals ("text") || message.getMessageType ().equals ("removed")) {
                viewHolder.show_message.setVisibility (View.VISIBLE);
                viewHolder.show_message.setText (message.getMessage ());
                viewHolder.imageMessage.setVisibility (View.GONE);
                viewHolder.videoLayoutChat.setVisibility (View.GONE);
                viewHolder.pdfChatMessage.setVisibility (View.GONE);
            }
            else if(message.getMessageType ().equals ("image")){
                viewHolder.show_message.setVisibility (View.GONE);
                Picasso.get ().load (message.getMessage()).into (viewHolder.imageMessage);
                viewHolder.imageMessage.setVisibility (View.VISIBLE);
                viewHolder.videoLayoutChat.setVisibility (View.GONE);
                viewHolder.pdfChatMessage.setVisibility (View.GONE);
            }
            else if(message.getMessageType ().equals ("video")){
                viewHolder.show_message.setVisibility (View.GONE);
                viewHolder.imageMessage.setVisibility (View.GONE);
                viewHolder.videoLayoutChat.setVisibility (View.VISIBLE);
                viewHolder.pdfChatMessage.setVisibility (View.GONE);
                //viewHolder.videoMessage.setVideoURI (Uri.parse (message.getMessage ()));
            }
            else if(message.getMessageType ().equals ("pdf")){
                viewHolder.show_message.setVisibility (View.GONE);
                viewHolder.imageMessage.setVisibility (View.GONE);
                viewHolder.videoLayoutChat.setVisibility (View.GONE);
                viewHolder.pdfChatMessage.setVisibility (View.VISIBLE);
            }
        }

        int reactions[] = new int[]{
                R.drawable.ic_fb_angry,
                R.drawable.ic_fb_laugh,
                R.drawable.ic_fb_angry,
                R.drawable.ic_fb_like,
                R.drawable.ic_fb_sad,
                R.drawable.ic_fb_wow,
                R.drawable.ic_fb_love
        };
        ReactionsConfig config = new ReactionsConfigBuilder (mContext)
                .withReactions (reactions).build ();

        ReactionPopup popup = new ReactionPopup (
                mContext, config, (pos) -> {

                    if(pos>=0 && pos<7) {
                        if (holder.getClass () == SentViewHolder.class) {
                            SentViewHolder viewHolder = (SentViewHolder) holder;
                            viewHolder.feelings.setImageResource (reactions[pos]);
                            viewHolder.feelings.setVisibility (View.VISIBLE);
                        } else {
                            ReceiverViewHolder viewHolder = (ReceiverViewHolder) holder;
                            viewHolder.feelings.setImageResource (reactions[pos]);
                            viewHolder.feelings.setVisibility (View.VISIBLE);
                        }

                        message.setFeeling (pos);
                    }

                    FirebaseDatabase.getInstance ().getReference ().child ("chats")
                            .child (senderRoom).child ("messages").child (message.getMessageId ())
                            .setValue (message);

                    checkForMessage (message);

           // Log.d("message firebase",checkForMessage (message)+" ");
            return true;
        });

        if(holder.getClass ()==SentViewHolder.class){
            SentViewHolder viewHolder=(SentViewHolder)holder;
            if(message.getFeeling ()>=0){
                viewHolder.feelings.setImageResource (reactions[message.getFeeling ()]);
                viewHolder.feelings.setVisibility (View.VISIBLE);
            }else{
                viewHolder.feelings.setVisibility (View.GONE);
            }

            viewHolder.videoLayoutChat.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(message.getMessage ()));
                    mContext.startActivity (i);
                }
            });

            viewHolder.pdfChatMessage.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(message.getMessage ()));
                    mContext.startActivity (i);
                }
            });

            viewHolder.videoImageChat.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    popup.onTouch (v,event);
                    return true;
                }
            });

            viewHolder.pdfChat.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    popup.onTouch (v,event);
                    return true;
                }
            });

            viewHolder.imageMessage.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    popup.onTouch (v,event);
                    return true;
                }
            });
            viewHolder.show_message.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    if(message.getMessageType ().equals ("text")) {
                        popup.onTouch (v, event);
                        return true;
                    }
                    else{
                        return false;
                    }
                }
            });

            viewHolder.itemView.setOnLongClickListener (new View.OnLongClickListener () {
                @Override
                public boolean onLongClick (View v) {
                    //dialog
                    View view=LayoutInflater.from (mContext).inflate (R.layout.delete_dialog,null);
                    DeleteDialogBinding binding=DeleteDialogBinding.bind (view);
                    AlertDialog dialog=new AlertDialog.Builder (mContext)
                            .setTitle ("Delete Message")
                            .setView (binding.getRoot ())
                            .create ();

                    binding.everyone.setOnClickListener (new View.OnClickListener () {
                        @Override
                        public void onClick (View v) {
                            message.setMessage("this message is removed");
                            message.setFeeling (-1);
                            message.setMessageType ("removed");
                            FirebaseDatabase.getInstance ().getReference ()
                                    .child ("chats")
                                    .child (senderRoom)
                                    .child ("messages")
                                    .child (message.getMessageId ()).setValue (message);

                            checkForMessage (message);

                            dialog.dismiss ();
                        }
                    });

                    binding.delete.setOnClickListener (new View.OnClickListener () {
                        @Override
                        public void onClick (View v) {
                            FirebaseDatabase.getInstance ().getReference ()
                                    .child ("chats").child (senderRoom)
                                    .child ("messages")
                                    .child (message.getMessageId ()).setValue (null);
                            dialog.dismiss ();
                        }
                    });

                    binding.cancel.setOnClickListener (new View.OnClickListener () {
                        @Override
                        public void onClick (View v) {
                            dialog.dismiss ();
                        }
                    });

                    if(!message.getMessageType ().equals ("removed")) {
                        dialog.show ();
                    }
                    return false;
                }
            });

        }else{
            ReceiverViewHolder viewHolder=(ReceiverViewHolder)holder;

            if(message.getFeeling ()>=0){
                viewHolder.feelings.setImageResource (reactions[message.getFeeling ()]);
                viewHolder.feelings.setVisibility (View.VISIBLE);
            }else{
                viewHolder.feelings.setVisibility (View.GONE);
            }

            viewHolder.videoLayoutChat.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(message.getMessage ()));
                    mContext.startActivity (i);
                }
            });

            viewHolder.pdfChatMessage.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(message.getMessage ()));
                    mContext.startActivity (i);
                }
            });

            viewHolder.videoImageChat.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    popup.onTouch (v,event);
                    return true;
                }
            });

            viewHolder.pdfChat.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    popup.onTouch (v,event);
                    return true;
                }
            });

            viewHolder.imageMessage.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    popup.onTouch (v,event);
                    return true;
                }
            });

            viewHolder.show_message.setOnTouchListener (new View.OnTouchListener () {
                @Override
                public boolean onTouch (View v, MotionEvent event) {
                    if(message.getMessageType ().equals ("text")) {
                        popup.onTouch (v, event);
                        return true;
                    }else{
                        return false;
                    }
                }
            });

            viewHolder.itemView.setOnLongClickListener (new View.OnLongClickListener () {
                @Override
                public boolean onLongClick (View v) {
                    View view=LayoutInflater.from (mContext).inflate (R.layout.delete_dialog,null);
                    DeleteDialogBinding binding=DeleteDialogBinding.bind (view);
                    AlertDialog dialog=new AlertDialog.Builder (mContext)
                            .setTitle ("Delete Message")
                            .setView (binding.getRoot ())
                            .create ();

                    binding.everyone.setVisibility (View.GONE);

                    binding.delete.setOnClickListener (new View.OnClickListener () {
                        @Override
                        public void onClick (View v) {
                            FirebaseDatabase.getInstance ().getReference ()
                                    .child ("chats")
                                    .child (senderRoom)
                                    .child ("messages")
                                    .child (message.getMessageId ()).setValue (null);

                            dialog.dismiss ();
                        }
                    });

                    binding.cancel.setOnClickListener (new View.OnClickListener () {
                        @Override
                        public void onClick (View v) {
                            dialog.dismiss ();
                        }
                    });

                    if(!message.getMessageType ().equals ("removed")) {
                        dialog.show ();
                    }
                    return false;
                }
            });
        }

    }

    @Override
    public int getItemCount () {
        return mChat.size ();
    }

    public class SentViewHolder extends RecyclerView.ViewHolder {

        public TextView show_message;
        public ImageView feelings;
        public RelativeLayout relativeLayout;
        public ImageView imageMessage,pdfChat,videoImageChat;
        public TextView videoMessage,pdfChatName;
        public RelativeLayout pdfChatMessage,videoLayoutChat;

        public SentViewHolder (@NonNull View itemView) {
            super (itemView);

            show_message = itemView.findViewById (R.id.show_message);
            feelings = itemView.findViewById (R.id.reactionChat);
            relativeLayout=itemView.findViewById (R.id.itemViewLayout);
            imageMessage=itemView.findViewById (R.id.imageChatMessage);
            videoMessage=itemView.findViewById (R.id.videoChatMessage);
            pdfChatMessage=itemView.findViewById (R.id.pdfChatMessage);
            pdfChat=itemView.findViewById (R.id.pdfChat);
            pdfChatName=itemView.findViewById (R.id.pdfChatName);
            videoLayoutChat=itemView.findViewById (R.id.videoLayoutChat);
            videoImageChat=itemView.findViewById (R.id.videoImageChat);



        }
    }

    public class ReceiverViewHolder extends RecyclerView.ViewHolder {

        public TextView show_message;
        public ImageView profile_image;
        public ImageView feelings;
        public RelativeLayout relativeLayout;
        public ImageView imageMessage,pdfChat,videoImageChat;
        public TextView videoMessage,pdfChatName;
        public RelativeLayout pdfChatMessage,videoLayoutChat;

        public ReceiverViewHolder (@NonNull View itemView) {
            super (itemView);

            show_message = itemView.findViewById (R.id.show_message);
            profile_image = itemView.findViewById (R.id.profile_image);
            feelings = itemView.findViewById (R.id.reactionChat);
            relativeLayout=itemView.findViewById (R.id.itemViewLayout);
            imageMessage=itemView.findViewById (R.id.imageChatMessage);
            videoMessage=itemView.findViewById (R.id.videoChatMessage);
            pdfChatMessage=itemView.findViewById (R.id.pdfChatMessage);
            pdfChat=itemView.findViewById (R.id.pdfChat);
            pdfChatName=itemView.findViewById (R.id.pdfChatName);
            videoLayoutChat=itemView.findViewById (R.id.videoLayoutChat);
            videoImageChat=itemView.findViewById (R.id.videoImageChat);

        }
    }

    private void checkForMessage(Chat message){
        FirebaseDatabase.getInstance ().getReference ().child ("chats")
                .child (receiverRoom).child ("messages").child (message.getMessageId ()).addListenerForSingleValueEvent (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ()){
                    FirebaseDatabase.getInstance ().getReference ()
                        .child ("chats")
                        .child (receiverRoom).child ("messages")
                        .child (message.getMessageId ()).setValue (message);
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
    }
}

