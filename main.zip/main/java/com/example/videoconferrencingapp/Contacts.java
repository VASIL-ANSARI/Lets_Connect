package com.example.videoconferrencingapp;

import java.io.Serializable;

public class Contacts implements Serializable {
    String Name,image,Status,uid,fcm_token;

    public Contacts() {

    }

    public Contacts(String Name, String image, String Status, String uid) {
        this.Name = Name;
        this.image = image;
        this.Status = Status;
        this.uid = uid;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getFcm_token () {
        return fcm_token;
    }

    public void setFcm_token (String fcm_token) {
        this.fcm_token = fcm_token;
    }
}
