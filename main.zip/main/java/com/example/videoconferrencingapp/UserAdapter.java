package com.example.videoconferrencingapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.common.collect.BiMap;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.auth.User;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
    private Context mContext;
    private List<Contacts> users;
    private UsersListener usersListener;
    private List<Contacts> selectedUsers;


    public UserAdapter(Context mContext, List<Contacts> users,UsersListener usersListener) {
        this.mContext = mContext;
        this.users = users;
        this.usersListener=usersListener;
        selectedUsers=new ArrayList<> ();
    }

    public List<Contacts> getSelectedUsers(){
        return selectedUsers;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.contact_design,parent,false);
        return new UserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Contacts contacts=users.get(position);

        String senderId= FirebaseAuth.getInstance ().getUid ();
        String senderRoom=senderId+contacts.getUid ();



        FirebaseDatabase.getInstance ().getReference ().child ("chats").child (senderRoom)
                .addValueEventListener (new ValueEventListener () {
                    @Override
                    public void onDataChange (@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists ()) {
                            String lastMsg = snapshot.child ("lastMsg").getValue (String.class);
                            if(lastMsg.length ()>17){
                                holder.lastMsg.setText (lastMsg.substring (0,17)+"...");
                            }
                            else{
                                holder.lastMsg.setText (lastMsg);
                            }
                            long time = snapshot.child ("lastMsgTime").getValue (Long.class);
                            SimpleDateFormat dateFormat = new SimpleDateFormat ("E,dd MMM yyyy hh:mm a");
                            holder.MsgTime.setText(dateFormat.format(new Date (time)));

                        }
                        else{
                            holder.lastMsg.setText ("Tap Chat icon to Chat");
                            holder.MsgTime.setText ("");
                        }
                    }

                    @Override
                    public void onCancelled (@NonNull DatabaseError error) {

                    }
                });

//        FirebaseDatabase.getInstance ().getReference ().child ("ClearChats").addValueEventListener (new ValueEventListener () {
//            @Override
//            public void onDataChange (@NonNull DataSnapshot snapshot) {
//                for(DataSnapshot snapshot1:snapshot.getChildren ()){
//                    if(snapshot1.child ("from").getValue ().equals (FirebaseAuth.getInstance ().getCurrentUser ().getUid ()) &&
//                            snapshot1.child ("to").getValue ().equals (contacts.getUid ())){
//                        holder.MsgTime.setText ("");
//                        holder.lastMsg.setText ("Tap to Chat");
//                    }
//                }
//
//
//            }
//
//            @Override
//            public void onCancelled (@NonNull DatabaseError error) {
//
//            }
//        });

        holder.userName.setText(contacts.getName());
        if(contacts.getImage().equals(""))
        {
            holder.profile_image.setImageResource(R.drawable.profile_image);
        }
        else
        {
            Picasso.get().load(contacts.getImage()).into(holder.profile_image);
        }
        holder.chat_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mContext,MessageActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("userid",contacts.getUid());
                mContext.startActivity(intent);
            }
        });

        holder.video_call_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usersListener.initiateVideoMeeting(contacts);
            }
        });

        holder.audio_btn.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                usersListener.initiateAudioMeeting (contacts);
            }
        });

        holder.constraintLayout.setOnLongClickListener (new View.OnLongClickListener () {
            @Override
            public boolean onLongClick (View v) {
                if(holder.imageSelected.getVisibility ()!=View.VISIBLE && contacts.getFcm_token ()!=null){
                    selectedUsers.add(contacts);
                    holder.imageSelected.setVisibility (View.VISIBLE);
                    holder.video_call_btn.setVisibility (View.GONE);
                    holder.chat_btn.setVisibility (View.GONE);
                    holder.audio_btn.setVisibility (View.GONE);
                    usersListener.onMultipleUserAction (true);
                }
                else if(contacts.getFcm_token ()==null){
                    Toast.makeText (mContext,"This user is not available for conference right now",Toast.LENGTH_SHORT).show ();
                }
                return true;
            }
        });

        holder.constraintLayout.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                if(holder.imageSelected.getVisibility ()==View.VISIBLE){
                    selectedUsers.remove (contacts);
                    holder.imageSelected.setVisibility (View.GONE);
                    holder.video_call_btn.setVisibility (View.VISIBLE);
                    holder.chat_btn.setVisibility (View.VISIBLE);
                    holder.audio_btn.setVisibility (View.VISIBLE);
                    if(selectedUsers.size ()==0){
                        usersListener.onMultipleUserAction (false);
                    }
                }else{
                    if(selectedUsers.size ()>0 && contacts.getFcm_token ()!=null){
                        selectedUsers.add (contacts);
                        holder.imageSelected.setVisibility (View.VISIBLE);
                        holder.video_call_btn.setVisibility (View.GONE);
                        holder.chat_btn.setVisibility (View.GONE);
                        holder.audio_btn.setVisibility (View.GONE);
                    }
                    else if(contacts.getFcm_token ()==null){
                        Toast.makeText (mContext,"This user is not available for conference right now",Toast.LENGTH_SHORT).show ();
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView userName,lastMsg,MsgTime;
        public ImageView profile_image;
        public Button video_call_btn,chat_btn,audio_btn;
        FrameLayout constraintLayout;
        ImageView imageSelected;
        RelativeLayout viewForeground,viewBackground;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            userName=itemView.findViewById(R.id.name_contacts);
            profile_image=itemView.findViewById(R.id.image_contact);
            video_call_btn=itemView.findViewById(R.id.call_btn);
            chat_btn=itemView.findViewById(R.id.chat_btn);
            audio_btn=itemView.findViewById (R.id.audio_btn);
            viewBackground=itemView.findViewById (R.id.card_view2);
            viewForeground=itemView.findViewById (R.id.card_view1);
            lastMsg=itemView.findViewById (R.id.lastMsg);
            MsgTime=itemView.findViewById (R.id.msgTime);

            constraintLayout=itemView.findViewById (R.id.userContainer);

            imageSelected=itemView.findViewById (R.id.imageSelected);

        }
    }

}
