package com.example.videoconferrencingapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {

    private Button saveBtn;
    private EditText userNameET,userBioET;
    private ImageView profileImageView;
    private static int gallerypick=1;
    private Uri imageUri;
    private StorageReference userProfileImaRef;
    private String downloadUrl;
    private DatabaseReference userRef;

    Uri filePath;
    String mCurrentPhotoPath;

    private ProgressDialog progressDialog;
    public static final int RequestPermissionCode = 1;
    private File file;
    Uri uri;
    FirebaseFirestore database;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder(); StrictMode.setVmPolicy(builder.build());

        EnableRuntimePermission();
        database=FirebaseFirestore.getInstance();
        preferenceManager=new PreferenceManager(getApplicationContext());

        userProfileImaRef= FirebaseStorage.getInstance().getReference().child("Profile Image");

        userRef= FirebaseDatabase.getInstance().getReference().child("Users");
        userRef.keepSynced(true);
        saveBtn=findViewById(R.id.save_settings_btn);
        userNameET=findViewById(R.id.username_settings);
        userBioET=findViewById(R.id.bio_settings);
        profileImageView=findViewById(R.id.settings_profile_image);
        progressDialog=new ProgressDialog(this);

        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder=new AlertDialog.Builder(SettingsActivity.this);
                builder.setTitle("Select any one option:");
                builder.setPositiveButton("Take Photo From Camera", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                int MyVersion = Build.VERSION.SDK_INT;
                                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                                    checkIfAlreadyhavePermission();
                                }

                                if (hasCamera()) {
                                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                    // Ensure that there's a camera activity to handle the intent
                                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                                        // Create the File where the photo should go
                                        File photoFile = null;
                                        try {
                                            photoFile = createImageFile();
                                        } catch (IOException ex) {
                                            // Error occurred while creating the File

                                        }
                                        // Continue only if the File was successfully created
                                        if (photoFile != null) {
                                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                                                    Uri.fromFile(photoFile));
                                            filePath = Uri.fromFile(photoFile);
                                            Log.e("Uri ", filePath + "");
                                            startActivityForResult(takePictureIntent, 7);
                                        }
                                    }

                                }
                            }
                        });
                builder.setNegativeButton("Take photo from Gallery", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent galleryIntent=new Intent();
                        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                        galleryIntent.setType("image/*");
                        startActivityForResult(galleryIntent,gallerypick);
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();


            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserData();
            }
        });

        retriveUserInfo();


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==gallerypick && resultCode==RESULT_OK && data!=null)
        {
            imageUri=data.getData();
            profileImageView.setImageURI(imageUri);
        }
        if (requestCode == 7 && resultCode == RESULT_OK) {
            CropImage.activity(filePath).setAspectRatio(1,1)
                    .start(SettingsActivity.this);
        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            Uri resultUri = result.getUri();
            imageUri=resultUri;
            profileImageView.setImageURI(imageUri);
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean checkIfAlreadyhavePermission() {


        checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if((checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)) {

            //show dialog to ask permission
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    1);
            return true;
        } else {
            return false;
        }

    }

    private void saveUserData()
    {
        final String getUserName=userNameET.getText().toString();
        final String getUserStatus=userBioET.getText().toString();

        if(imageUri==null)
        {
            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).hasChild("image"))
                    {
                        saveInfoOnlyWithoutImage();
                    }
                    else{

                        Toast.makeText(SettingsActivity.this,"Please select Image",Toast.LENGTH_SHORT).show();
                    }



                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        else if(getUserName.equals("")){
            Toast.makeText(this,"User name is mandatory",Toast.LENGTH_SHORT).show();

        }
        else if(getUserStatus.equals("")){
            Toast.makeText(this,"Bio is mandatory",Toast.LENGTH_SHORT).show();
        }
        else
        {

            progressDialog.setTitle("Account Settings");
            progressDialog.setMessage("Please Wait...");
            progressDialog.show();
            final StorageReference filePath=userProfileImaRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid());

            final UploadTask uploadTask=filePath.putFile(imageUri);

            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if(!task.isSuccessful())
                    {
                        throw task.getException();
                    }

                    downloadUrl=filePath.getDownloadUrl().toString();

                    return filePath.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if(task.isSuccessful())
                    {
                        downloadUrl=task.getResult().toString();
                        HashMap<String,Object> profileMap=new HashMap<>();
                        profileMap.put("uid",FirebaseAuth.getInstance().getCurrentUser().getUid());
                        profileMap.put("Name",getUserName);
                        profileMap.put("Status",getUserStatus);
                        profileMap.put("image",downloadUrl);



                        userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .updateChildren(profileMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful())
                                {

                                    preferenceManager.putBoolean(Constants.KEY_IS_SIGNED_IN,true);
                                    preferenceManager.putString(Constants.KEY_NAME,getUserName);
                                    preferenceManager.putString(Constants.KEY_STATUS,getUserStatus);
                                    preferenceManager.putString(Constants.KEY_USER_ID,FirebaseAuth.getInstance().getCurrentUser().getUid());

                                    Intent intent=new Intent(SettingsActivity.this,ContextActivity.class);
                                    startActivity(intent);
                                    finish();

                                    progressDialog.dismiss();

                                    Toast.makeText(SettingsActivity.this,"Profile settings updated",Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            });
        }
    }

    private void saveInfoOnlyWithoutImage()
    {
        final String getUserName=userNameET.getText().toString();
        final String getUserStatus=userBioET.getText().toString();




        if(getUserName.equals("")){
            Toast.makeText(this,"User name is mandatory",Toast.LENGTH_SHORT).show();

        }
        else if(getUserStatus.equals("")){
            Toast.makeText(this,"Bio is mandatory",Toast.LENGTH_SHORT).show();
        }
        else {
            HashMap<String,Object> profileMap=new HashMap<>();
            profileMap.put("uid",FirebaseAuth.getInstance().getCurrentUser().getUid());
            profileMap.put("Name",getUserName);
            profileMap.put("Status",getUserStatus);


            userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                    .updateChildren(profileMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful())
                    {

                        preferenceManager.putBoolean (Constants.KEY_IS_SIGNED_IN, true);
                        preferenceManager.putString (Constants.KEY_NAME, getUserName);
                        preferenceManager.putString (Constants.KEY_STATUS, getUserStatus);
                        preferenceManager.putString (Constants.KEY_USER_ID, FirebaseAuth.getInstance ().getCurrentUser ().getUid ());

                        Intent intent=new Intent(SettingsActivity.this,ContextActivity.class);
                        startActivity(intent);
                        finish();

                        Toast.makeText(SettingsActivity.this,"Profile settings updated",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }


    }

    private void retriveUserInfo()
    {
        progressDialog.setTitle("Retrieving Account Settings");
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot!=null && snapshot.exists())
                {
                    String imageDb=snapshot.child("image").getValue().toString();
                    String UserNameDb=snapshot.child("Name").getValue().toString();
                    String BioDb=snapshot.child("Status").getValue().toString();

                    userNameET.setText(UserNameDb);
                    userBioET.setText(BioDb);

                    Picasso.get().load(imageDb).placeholder(R.drawable.profile_image).into(profileImageView);


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        progressDialog.dismiss ();
    }

    public void EnableRuntimePermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(SettingsActivity.this,
                Manifest.permission.CAMERA)) {
            Toast.makeText(SettingsActivity.this,"CAMERA permission allows us to Access CAMERA app",     Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(SettingsActivity.this,new String[]{
                    Manifest.permission.CAMERA}, RequestPermissionCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] result) {
        switch (requestCode) {
            case RequestPermissionCode:
                if (result.length > 0 && result[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(SettingsActivity.this, "Permission Granted, Now your application can access CAMERA.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SettingsActivity.this, "Permission Canceled, Now your application cannot access CAMERA.", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    //new-code


    // create image file method used in above function
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat ("yyyyMMdd_HHmmss").format(new Date ());
        String imageFileName = "JPEG_" + timeStamp + "_";
        String storageDir = Environment.getExternalStorageDirectory() + "/picupload";
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        Log.e("photo path = " , mCurrentPhotoPath);

        return image;
    }

    // to check whether camera is present or not
    private boolean hasCamera()
    {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }


}