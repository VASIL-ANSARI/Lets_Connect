package com.example.videoconferrencingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.jitsi.meet.sdk.JitsiMeetOngoingConferenceService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.lang.ref.PhantomReference;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;
import java.util.function.Predicate;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OutgoingMeetingInvitationActivity extends AppCompatActivity {


    private PreferenceManager preferenceManager;
    private String invitationToken=null;
    Contacts user;
    String meetingRoom=null;
    private TextView textFirstChar;
    private TextView textUserName;

    private String meetingType=null;

    private int rejectionCount=0;
    private int totalReceivers=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outgoing_meeting_invitation);

        preferenceManager=new PreferenceManager(getApplicationContext());

        CircleImageView imageView=findViewById(R.id.meetingType);
        meetingType=getIntent().getStringExtra("meeting_type");

        if(meetingType!=null){
            if(meetingType.equals("video")){
                imageView.setImageResource(R.drawable.ic_video);
            }
            else{
                imageView.setImageResource (R.drawable.make_call);
            }
        }

         textFirstChar=findViewById(R.id.textFirstChar);
         textUserName=findViewById(R.id.textUserName);

        user=(Contacts)getIntent().getSerializableExtra("user");

        if(user!=null){
            textFirstChar.setText(user.getName().substring(0,1));
            textUserName.setText(String.format("%s",user.getName()));

        }

        ImageView imageCancelInvitation=findViewById(R.id.ImageStopInvitation);
        imageCancelInvitation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(getIntent ().getBooleanExtra ("isMultiple",false)){
                    Type type=new TypeToken<ArrayList<Contacts>> (){}.getType ();
                    ArrayList<Contacts> receivers=new Gson ().fromJson (getIntent ().getStringExtra ("selectedUsers"),type);
                    cancelInvitation (null,receivers);
                }
                else{
                    if(user!=null){
                        cancelInvitation(user.getFcm_token (),null);
                    }
                }

            }
        });

        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                if(task.isSuccessful() && task.getResult()!=null){

                    invitationToken=task.getResult().getToken();

                    if(meetingType!=null){
                        if(getIntent ().getBooleanExtra ("isMultiple",false)){
                            Type type=new TypeToken<ArrayList<Contacts>> (){}.getType ();
                            ArrayList<Contacts> receivers=new Gson ().fromJson (getIntent ().getStringExtra ("selectedUsers"),type);
                            if(receivers!=null){
                                totalReceivers=receivers.size ();
                            }

                            initiateMeeting (meetingType,null,receivers);
                        }else{
                            if(meetingType!=null && user!=null){
                                Log.d("message :",meetingType+" "+invitationToken+" "+user.getFcm_token ());

                                totalReceivers=1;
                                initiateMeeting(meetingType,user.getFcm_token (),null);
                            }
                        }
                    }


                }
            }
        });



    }

    private void initiateMeeting(String MeetingType, String receiverToken, ArrayList<Contacts> receivers){
        try {
            JSONArray tokens=new JSONArray();

            if(receiverToken!=null){
                tokens.put(receiverToken);
            }
            if(receivers!=null && receivers.size ()>0){
                StringBuilder userNames=new StringBuilder ();
                for(int i=0;i<receivers.size ();i++){
                    tokens.put (receivers.get (i).getFcm_token ());
                    userNames.append (receivers.get (i).getName ()).append ("\n");
                }
                Log.d("message",userNames.toString ());
                textFirstChar.setVisibility (View.GONE);
                textUserName.setText (userNames.toString ());
            }





            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");


            reference.orderByChild(Constants.KEY_USER_ID).equalTo(FirebaseAuth.getInstance ().getCurrentUser ().getUid ()).addListenerForSingleValueEvent(new ValueEventListener () {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for(DataSnapshot datas: dataSnapshot.getChildren()){
                        String familyName =datas.child(Constants.KEY_NAME).getValue().toString();

                        JSONObject body=new JSONObject();
                        JSONObject data=new JSONObject();

                        try {
                            data.put(Constants.REMOTE_MSG_TYPE,Constants.REMOTE_MSG_INVITATION);
                            data.put(Constants.REMOTE_MSG_MEETING_TYPE,MeetingType);

                            data.put(Constants.KEY_NAME, familyName);
                            data.put(Constants.REMOTE_MSG_INVITER_TOKEN,invitationToken);


                            meetingRoom=user.getUid()+"_"+ UUID.randomUUID().toString().substring(0,5);
                            data.put(Constants.REMOTE_MEETING_ROOM,meetingRoom);

                            body.put(Constants.REMOTE_MSG_DATA,data);
                            body.put(Constants.REMOTE_MSG_REGISTRATION_IDS,tokens);
                        } catch (JSONException e) {
                            e.printStackTrace ();
                        }

                        Log.d("message Meeting: ",body.toString ());

                        sendRemoteMessage(body.toString(),Constants.REMOTE_MSG_INVITATION);

                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        }
        catch(Exception e){
            Toast.makeText(OutgoingMeetingInvitationActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void sendRemoteMessage(String remoteMessageBody,String type){
        ApiClient.getClient().create(ApiService.class).sendRemoteMessage(
                Constants.getRemoteMessageHeaders(),remoteMessageBody
        ).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NonNull Call<String> call,@NonNull Response<String> response) {

                if(response.isSuccessful()){
                    if(type.equals(Constants.REMOTE_MSG_INVITATION)){
                        Toast.makeText(OutgoingMeetingInvitationActivity.this,"Invitation Sent Successfully",Toast.LENGTH_SHORT).show();
                    }
                    else if(type.equals(Constants.REMOTE_MSG_INVITATION_RESPONSE)){
                        Toast.makeText(OutgoingMeetingInvitationActivity.this,"Invitation Cancelled",Toast.LENGTH_SHORT).show();
                        finish();
                    }


                }else{
                    Toast.makeText(OutgoingMeetingInvitationActivity.this,response.message(),Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onFailure(@NonNull Call<String> call,@NonNull Throwable t) {

                Toast.makeText(OutgoingMeetingInvitationActivity.this,t.getMessage(),Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void cancelInvitation(String receiverToken,ArrayList<Contacts> receivers){
        try{

            JSONArray tokens=new JSONArray();

            if(receiverToken!=null){
                tokens.put(receiverToken);
            }

            if(receivers!=null && receivers.size ()>0){
                for(Contacts user:receivers){
                    tokens.put (user.getFcm_token ());

                }
            }


            JSONObject body=new JSONObject();
            JSONObject data=new JSONObject();

            data.put(Constants.REMOTE_MSG_TYPE,Constants.REMOTE_MSG_INVITATION_RESPONSE);
            data.put(Constants.REMOTE_MSG_INVITATION_RESPONSE,Constants.REMOTE_MSG_INVITATION_CANCELLED);


            body.put(Constants.REMOTE_MSG_DATA,data);
            body.put(Constants.REMOTE_MSG_REGISTRATION_IDS,tokens);

            Log.d("message cancelled",body.toString ());

            sendRemoteMessage (body.toString (),Constants.REMOTE_MSG_INVITATION_RESPONSE);

        }catch(Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private BroadcastReceiver invitationResponseReceiver=new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String type=intent.getStringExtra(Constants.REMOTE_MSG_INVITATION_RESPONSE);

            if(type!=null){
                if(type.equals(Constants.REMOTE_MSG_INVITATION_ACCEPTED)){
                    try {
                        URL serverURL=new URL("https://meet.jit.si");

                        JitsiMeetConferenceOptions.Builder builder=new JitsiMeetConferenceOptions.Builder ();
                        builder.setServerURL (serverURL);
                        builder.setWelcomePageEnabled (false);
                        builder.setRoom (meetingRoom);

                        if(meetingType.equals ("audio")){
                            builder.setVideoMuted (true);
                        }



                        JitsiMeetActivity.launch(OutgoingMeetingInvitationActivity.this,builder.build ());
                        finish();
                    }catch(Exception e){
                        Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }else if(type.equals(Constants.REMOTE_MSG_INVITATION_REJECTED)){
                    rejectionCount+=1;
                    if(rejectionCount==totalReceivers){
                        Toast.makeText(context,"Invitation Rejected",Toast.LENGTH_SHORT).show();

                        finish();
                    }

                }
            }
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(
                invitationResponseReceiver,
                new IntentFilter(Constants.REMOTE_MSG_INVITATION_RESPONSE)
        );
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(
                invitationResponseReceiver
        );
    }
}