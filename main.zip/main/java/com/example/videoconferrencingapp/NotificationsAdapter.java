package com.example.videoconferrencingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NotificationsViewHolder> {

    private Context mContext;
    private List<Contacts> users;

    public NotificationsAdapter (Context mContext,List<Contacts> users) {
        this.mContext = mContext;
        this.users=users;
    }

    @NonNull
    @Override
    public NotificationsAdapter.NotificationsViewHolder onCreateViewHolder (@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.find_friends_design,parent,false);
        return new NotificationsAdapter.NotificationsViewHolder(view);
    }

    @Override
    public void onBindViewHolder (@NonNull NotificationsAdapter.NotificationsViewHolder holder, int position) {

        Contacts contacts=users.get (position);

        holder.userNameTxt.setText(contacts.getName());
        Picasso.get().load(contacts.getImage()).into(holder.profileImageView);
        getStatus(FirebaseAuth.getInstance ().getCurrentUser ().getUid (),contacts.getUid (),holder);
        holder.acceptBtn.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                AcceptRequest(FirebaseAuth.getInstance ().getCurrentUser ().getUid (),contacts.getUid ());
                holder.acceptBtn.setVisibility (View.GONE);
                holder.cancelBtn.setVisibility (View.GONE);
            }
        });
        holder.cancelBtn.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                RejectRequest(FirebaseAuth.getInstance ().getCurrentUser ().getUid (),contacts.getUid ());
              holder.cancelBtn.setVisibility (View.GONE);
              holder.acceptBtn.setVisibility (View.GONE);
            }
        });

    }

    private void AcceptRequest(String sender,String receiver){
        DatabaseReference requestRef= FirebaseDatabase.getInstance ().getReference ().child ("Requests");
        DatabaseReference friendRef= FirebaseDatabase.getInstance ().getReference ().child (Constants.STATUS_FRIEND);
        requestRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
            @Override
            public void onComplete (@NonNull Task<Void> task) {
                if(task.isSuccessful ()){

                    requestRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                        @Override
                        public void onComplete (@NonNull Task<Void> task) {
                            HashMap hashMap=new HashMap ();
                            hashMap.put ("status",Constants.STATUS_FRIEND);
                            hashMap.put ("uid",receiver);
                            friendRef.child (sender).child (receiver).updateChildren (hashMap)
                                    .addOnCompleteListener (new OnCompleteListener () {
                                        @Override
                                        public void onComplete (@NonNull Task task) {
                                            if(task.isSuccessful ())
                                            {
                                                HashMap hashMap1=new HashMap ();
                                                hashMap1.put ("status",Constants.STATUS_FRIEND);
                                                hashMap1.put ("uid",sender);
                                                friendRef.child (receiver).child (sender).updateChildren (hashMap1)
                                                        .addOnCompleteListener (new OnCompleteListener () {
                                                            @Override
                                                            public void onComplete (@NonNull Task task) {
                                                                Toast.makeText (mContext,"Congratulations! You added a new Friend",Toast.LENGTH_SHORT).show ();
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    });
                }
            }
        });
    }

    private void RejectRequest(String sender,String receiver){
        DatabaseReference requestRef= FirebaseDatabase.getInstance ().getReference ().child ("Requests");
        requestRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
            @Override
            public void onComplete (@NonNull Task<Void> task) {
                requestRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                    @Override
                    public void onComplete (@NonNull Task<Void> task) {
                        Toast.makeText (mContext,"You are no longer Friends",Toast.LENGTH_SHORT).show ();
                    }
                });
            }
        });
    }
    private void getStatus(String sender,String receiver,@NonNull NotificationsAdapter.NotificationsViewHolder holder){
        DatabaseReference friendRef= FirebaseDatabase.getInstance ().getReference ().child (Constants.STATUS_FRIEND);
        friendRef.child (sender).child (receiver).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists ()){
                    holder.acceptBtn.setVisibility (View.GONE);
                    holder.cancelBtn.setVisibility (View.GONE);
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public int getItemCount () {
        return users.size ();
    }
    public class NotificationsViewHolder extends RecyclerView.ViewHolder {
        TextView userNameTxt;
        Button acceptBtn,cancelBtn;
        ImageView profileImageView;
        RelativeLayout cardView;


        public NotificationsViewHolder(@NonNull View itemView) {
            super(itemView);

            userNameTxt=itemView.findViewById(R.id.name_notifications);
            acceptBtn=itemView.findViewById(R.id.request_accept_btn);
            cancelBtn=itemView.findViewById(R.id.request_decline_btn);
            profileImageView=itemView.findViewById(R.id.image_notification);
            cardView=itemView.findViewById(R.id.card_view);

        }
    }
}
