package com.example.videoconferrencingapp;

public class Chat {

    private String senderId;
    private String messageId;
    private String message;
    private  long timestamp;
    private int feeling=-1;
    private String messageType;

    public Chat() {
    }

    public Chat (String message, String senderId, long timestamp,String messageType) {
        this.senderId = senderId;
        this.message = message;
        this.timestamp = timestamp;
        this.messageType=messageType;
    }

    public String getSenderId () {
        return senderId;
    }

    public void setSenderId (String senderId) {
        this.senderId = senderId;
    }

    public String getMessageId () {
        return messageId;
    }

    public void setMessageId (String messageId) {
        this.messageId = messageId;
    }

    public String getMessage () {
        return message;
    }

    public void setMessage (String message) {
        this.message = message;
    }

    public long getTimestamp () {
        return timestamp;
    }

    public void setTimestamp (long timestamp) {
        this.timestamp = timestamp;
    }

    public int getFeeling () {
        return feeling;
    }

    public void setFeeling (int feeling) {
        this.feeling = feeling;
    }

    public String getMessageType () {
        return messageType;
    }

    public void setMessageType (String messageType) {
        this.messageType = messageType;
    }
}
