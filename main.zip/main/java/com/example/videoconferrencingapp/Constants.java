package com.example.videoconferrencingapp;

import java.util.HashMap;

public class Constants {

    public static final String KEY_COLLECTION_USERS="Users";
    public static final String KEY_NAME="Name";
    public static final String KEY_STATUS="Status";
    public static final String KEY_USER_ID="uid";
    public static final String KEY_FCM_TOKEN="fcm_token";

    public static final String KEY_PREFERENCE_NAME="VideoMeeting";
    public static final String KEY_IS_SIGNED_IN="isSignedIn";

    public static final String REMOTE_MSG_AUTHORIZATION="Authorization";
    public static final String REMOTE_MSG_CONTENT_TYPE="Content-Type";

    public static final String REMOTE_MSG_TYPE="type";
    public static final String REMOTE_MSG_INVITATION="invitation";
    public static final String REMOTE_MSG_MEETING_TYPE="meetingType";
    public static final String REMOTE_MSG_INVITER_TOKEN="inviterToken";
    public static final String REMOTE_MSG_DATA="data";
    public static final String REMOTE_MSG_REGISTRATION_IDS="registration_ids";

    public static final String REMOTE_MSG_INVITATION_RESPONSE="invitationResponse";
    public static final String REMOTE_MSG_INVITATION_ACCEPTED="accepted";
    public static final String REMOTE_MSG_INVITATION_REJECTED="rejected";
    public static final String REMOTE_MSG_INVITATION_CANCELLED="cancelled";

    public static final String REMOTE_MEETING_ROOM="meetingRoom";

    public static final String NOTHING_HAPPEN="nothing happen";
    public static final String STATUS_PENDING="pending";
    public static final String STATUS_SENT_PENDING="I_sent_pending";
    public static final String STATUS_SENT_DECLINE="I_sent_decline";
    public static final String SENT_PENDING="he_sent_pending";
    public static final String STATUS_FRIEND="friends";
    public static final String STATUS_DECLINE="decline";
    public static final String SENT_DECLINE="he_sent_decline";

    public static HashMap<String,String> getRemoteMessageHeaders(){
        HashMap<String,String> headers=new HashMap<>();
        headers.put(
                Constants.REMOTE_MSG_AUTHORIZATION,
                //add key here
                "key="
        );
        headers.put(Constants.REMOTE_MSG_CONTENT_TYPE,"application/json");
        return headers;
    }
}
