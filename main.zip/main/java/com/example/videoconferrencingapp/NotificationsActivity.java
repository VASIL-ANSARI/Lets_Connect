package com.example.videoconferrencingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private ShimmerRecyclerView notifications_list;
    List<Contacts> users;
    DatabaseReference requestRef,friendRef,userRef;
    FirebaseUser firebaseUser;
    NotificationsAdapter notificationsAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        notifications_list=findViewById(R.id.notifications_list);
        notifications_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        users=new ArrayList<> ();
        requestRef=FirebaseDatabase.getInstance ().getReference ().child ("Requests");
        friendRef=FirebaseDatabase.getInstance ().getReference ().child ("friends");
        userRef=FirebaseDatabase.getInstance ().getReference ().child ("Users");
        firebaseUser=FirebaseAuth.getInstance ().getCurrentUser ();
        notifications_list.showShimmerAdapter ();

        readData();

    }

    private  void readData()
    {
        requestRef.child (firebaseUser.getUid ()).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                users.clear ();
                for(DataSnapshot dataSnapshot:snapshot.getChildren ())
                {
                    String id=dataSnapshot.child ("uid").getValue (String.class);
                    String status=dataSnapshot.child ("status").getValue (String.class);
                    Log.d("message",id);

//                    FirebaseRecyclerOptions<Contacts> options=new FirebaseRecyclerOptions.Builder<Contacts>().setQuery(userRef.orderByKey ().equalTo (id),Contacts.class).build();;
//
//                    FirebaseRecyclerAdapter<Contacts,NotificationsActivity.NotificationsViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Contacts,NotificationsActivity.NotificationsViewHolder>(options) {
//                        @Override
//                        protected void onBindViewHolder(@NonNull NotificationsActivity.NotificationsViewHolder findFriendsViewHolder, int i, @NonNull Contacts contacts) {
//
//                            Log.d("message friends",contacts.getUid()+" "+contacts.getName()+" "+contacts.getStatus());
//
//                            findFriendsViewHolder.userNameTxt.setText(contacts.getName());
//                            Picasso.get().load(contacts.getImage()).into(findFriendsViewHolder.profileImageView);
//                        }
//
//                        @NonNull
//                        @Override
//                        public NotificationsActivity.NotificationsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//                            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.find_friends_design,parent,false);
//                            NotificationsActivity.NotificationsViewHolder viewHolder=new NotificationsActivity.NotificationsViewHolder (view);
//                            return viewHolder;
//                        }
//                    };
//                    notifications_list.setAdapter(firebaseRecyclerAdapter);
//                    firebaseRecyclerAdapter.startListening();

                    if(status.equals (Constants.STATUS_SENT_PENDING)){

                        Log.d("message","request type");

                        userRef.child (id).addListenerForSingleValueEvent (new ValueEventListener () {
                            @Override
                            public void onDataChange (@NonNull DataSnapshot snapshot) {
                                    if(snapshot.exists ())
                                    {
                                        Contacts contacts=snapshot.getValue (Contacts.class);
                                        users.add(contacts);
                                        Log.d("message user",users.toString ());
                                    }
                                if(users.size ()>0)
                                    Log.d("message users",users.get (0).getName ());
                                notificationsAdapter=new NotificationsAdapter (getApplicationContext (),users);
                                notifications_list.setAdapter (notificationsAdapter);
                                notificationsAdapter.notifyDataSetChanged ();
                            }

                            @Override
                            public void onCancelled (@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
                //Log.d("message friends",users.toString ());

            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
        friendRef.child (FirebaseAuth.getInstance ().getCurrentUser ().getUid ()).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren ())
                {
                    String id=dataSnapshot.child ("uid").getValue (String.class);
                    String status=dataSnapshot.child ("status").getValue (String.class);

                    if(status.equals (Constants.STATUS_FRIEND)){

                        Log.d("message","request type");

                        userRef.child (id).addListenerForSingleValueEvent (new ValueEventListener () {
                            @Override
                            public void onDataChange (@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists ())
                                {
                                    Contacts contacts=snapshot.getValue (Contacts.class);
                                    users.add(contacts);
                                    Log.d("message user",users.toString ());
                                }
                                if(users.size ()==0){
                                    TextView textView=findViewById (R.id.textViewVisible);
                                    textView.setVisibility (View.VISIBLE);
                                    notifications_list.setVisibility (View.GONE);
                                }
                                else {
                                    notificationsAdapter = new NotificationsAdapter (getApplicationContext (), users);
                                    notifications_list.setAdapter (notificationsAdapter);
                                    notificationsAdapter.notifyDataSetChanged ();
                                }
                            }

                            @Override
                            public void onCancelled (@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
        notifications_list.hideShimmerAdapter ();
        //notificationsAdapter.notifyDataSetChanged ();
    }

}