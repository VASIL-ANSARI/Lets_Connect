package com.example.videoconferrencingapp;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
