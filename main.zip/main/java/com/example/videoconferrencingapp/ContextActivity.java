package com.example.videoconferrencingapp;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.media.JetPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.google.android.gms.common.internal.GetServiceRequest;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.common.base.MoreObjects;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.internal.$Gson$Preconditions;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class ContextActivity extends AppCompatActivity implements UsersListener{

    BottomNavigationView navView;
    ShimmerRecyclerView myContactList;
    RelativeLayout relativeLayout;
    ImageView findPeopleBtn;
    List<Contacts> contactsList;
    private List<Contacts> cartLists;
    TopStatusAdapter statusAdapter;
    private ShimmerRecyclerView statusList;
    ArrayList<UserStatus> userStatuses;
    UserAdapter userAdapter;
    PreferenceManager preferenceManager;
    ImageView imageConference;
    private int REQUEST_CODE_BATTERY_OPTIMIZATIONS=1;
    ProgressDialog dialog;
    List<String> friendsList;
    Contacts user;
    private Paint p = new Paint ();

    private SwipeRefreshLayout swipeMenuListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_context);
        preferenceManager=new PreferenceManager(getApplicationContext());
        friendsList=new ArrayList<> ();

        dialog=new ProgressDialog (this);
        dialog.setMessage ("Uploading Image");
        dialog.setCancelable (false);

        imageConference=findViewById (R.id.imageConference);
        relativeLayout=findViewById (R.id.containerContext);
        statusList=findViewById (R.id.statusList);

        userStatuses=new ArrayList<> ();

        if(FirebaseAuth.getInstance ().getCurrentUser ()==null){
            finish ();
        }
        FirebaseDatabase.getInstance ().getReference ().child ("Users")
                .child (FirebaseAuth.getInstance ().getCurrentUser ().getUid ()).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                user=snapshot.getValue (Contacts.class);

            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });


        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                if(task.isSuccessful() && task.getResult()!=null){
                    sendFCMTokenToDatabase(task.getResult().getToken());
                }
            }
        });

        navView = findViewById(R.id.nav_view);
        swipeMenuListView=findViewById (R.id.swipeRefreshLayout);
        swipeMenuListView.setRefreshing (true);
        swipeMenuListView.setOnRefreshListener (new SwipeRefreshLayout.OnRefreshListener () {
            @Override
            public void onRefresh () {
                readUsers ();
            }
        });

        navView.setOnNavigationItemSelectedListener(navigationItemSelectedListener);
        findPeopleBtn=findViewById(R.id.find_people_btn);
        myContactList=findViewById(R.id.contact_list);
        myContactList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        myContactList.showShimmerAdapter ();

        //status set-up
        statusAdapter = new TopStatusAdapter(this, userStatuses);

        statusList.addItemDecoration(new DividerItemDecoration(ContextActivity.this, LinearLayoutManager.HORIZONTAL));
        LinearLayoutManager horizontalLayoutManager = new LinearLayoutManager(ContextActivity.this, LinearLayoutManager.HORIZONTAL, false);
        statusList.setLayoutManager(horizontalLayoutManager);


//        LinearLayoutManager layoutManager1 = new LinearLayoutManager(this);
//        layoutManager1.setOrientation(RecyclerView.HORIZONTAL);
//        statusList.setLayoutManager(layoutManager1);
        statusList.setAdapter(statusAdapter);
        statusList.showShimmerAdapter ();
        initSwipe ();


//        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
//        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(myContactList);



        findPeopleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent findpeopleIntent=new Intent(ContextActivity.this, FindPeopleActivity.class);
                startActivity(findpeopleIntent);
            }
        });

        myContactList.setHasFixedSize(false);
        myContactList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        myContactList.setItemAnimator(new DefaultItemAnimator ());
        myContactList.addItemDecoration(new DividerItemDecoration (this, DividerItemDecoration.VERTICAL));

        contactsList=new ArrayList<>();
        readUsers();
        checkForBatteryOptimization ();

    }

    private void getFriends(String userId){
        DatabaseReference friendRef=FirebaseDatabase.getInstance ().getReference ().child (Constants.STATUS_FRIEND);
        friendRef.child (userId).addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren ())
                {
                    String id=dataSnapshot.child ("uid").getValue (String.class);
                    friendsList.add (id);
                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
    }


    private void readUsers(){

        friendsList.clear ();
        getFriends(FirebaseAuth.getInstance ().getCurrentUser ().getUid ());
        Log.d("message friends",friendsList.toString ());

        swipeMenuListView.setRefreshing (true);
        imageConference.setVisibility (View.GONE);
        findPeopleBtn.setVisibility (View.VISIBLE);
        FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Users");
        Log.d("message",firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                contactsList.clear();
                for(DataSnapshot snapshot1:snapshot.getChildren()){

                    Contacts contacts=snapshot1.getValue(Contacts.class);
                    contacts.setName((String)snapshot1.child("Name").getValue());
                    contacts.setStatus((String)snapshot1.child("Status").getValue());

                    assert contacts!=null;
                    assert firebaseUser!=null;
                    if(friendsList.contains (contacts.getUid ())){
                        Log.d("message",contacts.getUid()+" "+contacts.getName()+" "+contacts.getStatus());
                        contactsList.add(contacts);
                    }
                }
                if(contactsList.size ()==0){
                    TextView textView=findViewById (R.id.textViewVisible1);
                    textView.setVisibility (View.VISIBLE);
                   // myContactList.setVisibility (View.GONE);

                }
                userAdapter = new UserAdapter (getApplicationContext (), contactsList, ContextActivity.this);
                myContactList.setAdapter (userAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        //status retrieval


        FirebaseDatabase.getInstance().getReference("stories").addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    userStatuses.clear();
                    for(DataSnapshot storySnapshot : snapshot.getChildren()) {
                        if (friendsList.contains (storySnapshot.getKey ()) || storySnapshot.getKey ().equals (firebaseUser.getUid ())) {
                            UserStatus status = new UserStatus ();
                            status.setName (storySnapshot.child ("name").getValue (String.class));
                            status.setProfileImage (storySnapshot.child ("profileImage").getValue (String.class));
                            status.setLastUpdated (storySnapshot.child ("lastUpdated").getValue (Long.class));

                            ArrayList<Status> statuses = new ArrayList<> ();

                            for (DataSnapshot statusSnapshot : storySnapshot.child ("statuses").getChildren ()) {
                                Status sampleStatus = statusSnapshot.getValue (Status.class);
                                statuses.add (sampleStatus);
                                Log.d ("message", sampleStatus.toString ());

                            }

                            status.setStatuses (statuses);
                            userStatuses.add (status);
                            Log.d ("message status", statuses.toString ());
                            Log.d ("message status", status.toString ());
                        }
                    }

                    statusAdapter.notifyDataSetChanged();
                }
                statusList.hideShimmerAdapter();
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
        swipeMenuListView.setRefreshing (false);

    }

    private BottomNavigationView.OnNavigationItemSelectedListener navigationItemSelectedListener=new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId())
            {
                case R.id.navigation_home:
//                    Intent mainIntent=new Intent(ContextActivity.this, ContextActivity.class);
//                    startActivity(mainIntent);
                    break;
                case R.id.navigation_settings:
                    Intent settingsIntent=new Intent(ContextActivity.this, SettingsActivity.class);
                    startActivity(settingsIntent);
                    break;
                case R.id.navigation_notifications:
                    Intent notificationsIntent=new Intent(ContextActivity.this,NotificationsActivity.class);
                    startActivity(notificationsIntent);
                    break;
                case R.id.navigation_logout:
                    AlertDialog.Builder builder=new AlertDialog.Builder (ContextActivity.this).setMessage ("Are you sure you want to logout?")
                            .setPositiveButton ("Yes", new DialogInterface.OnClickListener () {
                                @Override
                                public void onClick (DialogInterface dialog, int which) {
                                    dialog.dismiss ();
                                    HashMap<String,Object> updates=new HashMap<> ();
                                    updates.put(Constants.KEY_FCM_TOKEN,null);

                                    DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference().child("Users");
                                    databaseReference.child (FirebaseAuth.getInstance ().getCurrentUser ().getUid ()).child (Constants.KEY_FCM_TOKEN).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                                        @Override
                                        public void onComplete (@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                Log.d("message","token deleted");
                                                //preferenceManager.clearPreferences ();
                                                FirebaseAuth.getInstance().signOut();
                                                Intent logoutIntent=new Intent(ContextActivity.this,Registration.class);
                                                startActivity(logoutIntent);
                                                finish();
                                            }
                                        }
                                    });
                                }
                            }).setNegativeButton ("No", new DialogInterface.OnClickListener () {
                                @Override
                                public void onClick (DialogInterface dialog, int which) {
                                    dialog.dismiss ();
                                }
                            });
                    builder.create ().show ();

                    break;

                case R.id.status_menu:
                    Intent intent=new Intent ();
                    intent.setType ("image/*");
                    intent.setAction (Intent.ACTION_GET_CONTENT);
                    startActivityForResult (intent,75);
                    break;
            }
            return true;
        }
    };

    private void sendFCMTokenToDatabase(String token){
        HashMap<String,Object> hashMap=new HashMap<> ();
        hashMap.put(Constants.KEY_FCM_TOKEN,token);
        DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference().child("Users");
        databaseReference.child (FirebaseAuth.getInstance ().getCurrentUser ().getUid ())
                .updateChildren (hashMap).addOnCompleteListener (new OnCompleteListener<Void> () {
            @Override
            public void onComplete (@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {

                    //Toast.makeText(ContextActivity.this,"Token updated",Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    @Override
    public void initiateAudioMeeting(Contacts user) {

        if(user.getFcm_token ()==null || user.getFcm_token ().trim ().isEmpty ()){
            Toast.makeText(this,user.getName()+" is not available right now",Toast.LENGTH_SHORT).show();
        }
        else {

            Toast.makeText (this, "Audio Meeting with " + user.getName (), Toast.LENGTH_SHORT).show ();

            Intent intent = new Intent (getApplicationContext (), OutgoingMeetingInvitationActivity.class);
            intent.putExtra ("user", user);
            intent.putExtra ("meeting_type", "audio");
            startActivity (intent);
        }

    }

    @Override
    public void onMultipleUserAction (Boolean b) {

        if(b){
            imageConference.setVisibility (View.VISIBLE);
            findPeopleBtn.setVisibility (View.GONE);
            imageConference.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    Intent intent=new Intent (getApplicationContext (),OutgoingMeetingInvitationActivity.class);
                    intent.putExtra ("selectedUsers",new Gson().toJson (userAdapter.getSelectedUsers ()));
                    intent.putExtra ("meeting_type","video");
                    intent.putExtra ("isMultiple",true);
                    startActivity (intent);
                }
            });
        }else{
            imageConference.setVisibility (View.GONE);
        }
    }

    @Override
    public void initiateVideoMeeting(Contacts user) {
        if(user.getFcm_token ()==null || user.getFcm_token ().trim ().isEmpty ()){
            Toast.makeText(this,user.getName()+" is not available right now",Toast.LENGTH_SHORT).show();
        }
        else {

            Toast.makeText (this, "Video Meeting with " + user.getName (), Toast.LENGTH_SHORT).show ();

            Intent intent = new Intent (getApplicationContext (), OutgoingMeetingInvitationActivity.class);
            intent.putExtra ("user", user);
            intent.putExtra ("meeting_type", "video");
            startActivity (intent);
        }

    }

    private void checkForBatteryOptimization(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N){
            PowerManager powerManager=(PowerManager)getSystemService (POWER_SERVICE);
            if(!powerManager.isIgnoringBatteryOptimizations (getPackageName ())){
                AlertDialog.Builder builder=new AlertDialog.Builder (ContextActivity.this);
                builder.setTitle ("Warning");
                builder.setMessage ("Battery optimization is enabled.It can interrupt remaining background services.");

                builder.setPositiveButton ("Disable", new DialogInterface.OnClickListener () {
                    @Override
                    public void onClick (DialogInterface dialog, int which) {
                        Intent intent=new Intent (Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                        startActivityForResult (intent,REQUEST_CODE_BATTERY_OPTIMIZATIONS);
                    }
                });

                builder.setNegativeButton ("Cancel", new DialogInterface.OnClickListener () {
                    @Override
                    public void onClick (DialogInterface dialog, int which) {
                        dialog.dismiss ();
                    }
                });
                builder.create ().show ();
            }
        }
    }

    @Override
    protected void onActivityResult (int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult (requestCode, resultCode, data);
        if(requestCode==REQUEST_CODE_BATTERY_OPTIMIZATIONS){
            checkForBatteryOptimization ();
        }
        if(requestCode==75){
            if(data!=null && data.getData ()!=null){
                dialog.show ();
                FirebaseStorage storage=FirebaseStorage.getInstance ();
                Date date=new Date ();
                StorageReference reference=storage.getReference ().child ("status")
                        .child (date.getTime ()+ "");
                reference.putFile (data.getData ()).addOnCompleteListener (new OnCompleteListener<UploadTask.TaskSnapshot> () {
                    @Override
                    public void onComplete (@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful ()){
                            reference.getDownloadUrl ().addOnSuccessListener (new OnSuccessListener<Uri> () {
                                @Override
                                public void onSuccess (Uri uri) {

                                    UserStatus userStatus=new UserStatus ();
                                    userStatus.setName (user.getName ());
                                    userStatus.setProfileImage (user.getImage ());
                                    userStatus.setLastUpdated (date.getTime ());

                                    HashMap<String,Object> obj=new HashMap<> ();
                                    obj.put ("name",userStatus.getName ());
                                    obj.put ("profileImage",userStatus.getProfileImage ());
                                    obj.put ("lastUpdated",userStatus.getLastUpdated ());

                                    String imageUrl=uri.toString ();
                                    Status status=new Status (imageUrl,userStatus.getLastUpdated ());


                                    FirebaseDatabase.getInstance ().getReference ().child ("stories")
                                            .child (FirebaseAuth.getInstance ().getUid ()).updateChildren (obj);

                                    FirebaseDatabase.getInstance ().getReference ().child ("stories")
                                            .child (FirebaseAuth.getInstance ().getUid ())
                                            .child ("statuses").push ().setValue (status);
                                    readUsers ();
                                    dialog.dismiss ();
                                }
                            });
                        }
                    }
                }).addOnProgressListener (new OnProgressListener<UploadTask.TaskSnapshot> () {
                    @Override
                    public void onProgress (@NonNull UploadTask.TaskSnapshot snapshot) {
                        //dialog.setTitle (Math.toIntExact ((snapshot.getBytesTransferred () * 100 / snapshot.getTotalByteCount ())));
                    }
                });
            }
        }
    }

    private void initSwipe(){
        ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                String name=contactsList.get (position).getName ();

                if (viewHolder instanceof UserAdapter.ViewHolder) {

                    if (direction == ItemTouchHelper.LEFT) {
                        // ((UserAdapter.ViewHolder) viewHolder).viewBackground.setVisibility (View.VISIBLE);
                        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder (ContextActivity.this)
                                .setTitle ("Are You Sure you want to clear all chats")
                                .setPositiveButton ("Yes", new DialogInterface.OnClickListener () {
                                    @Override
                                    public void onClick (DialogInterface dialog, int which) {
                                        HashMap<String, String> hashMap = new HashMap<> ();
                                        Snackbar snackbar = Snackbar
                                                .make (relativeLayout, "All Chats Cleared", Snackbar.LENGTH_LONG);
                                        snackbar.setAction ("UNDO", new View.OnClickListener () {
                                            @Override
                                            public void onClick (View view) {
                                                hashMap.clear ();
                                                Toast.makeText (ContextActivity.this, "All Chats Restored", Toast.LENGTH_SHORT).show ();
                                                // undo is selected, restore the deleted item
                                            }
                                        });
                                        snackbar.setActionTextColor (Color.YELLOW);
                                        snackbar.show ();

                                        String id = FirebaseAuth.getInstance ().getCurrentUser ().getUid () +contactsList.get (position).getUid ();
                                        hashMap.put ("from", FirebaseAuth.getInstance ().getCurrentUser ().getUid ());
                                        hashMap.put ("to", contactsList.get (position).getUid ());
                                        Log.d ("message", FirebaseAuth.getInstance ().getCurrentUser ().getUid () + " " + contactsList.get (position).getUid ());
                                        snackbar.addCallback (new Snackbar.Callback () {

                                            @Override
                                            public void onDismissed (Snackbar snackbar, int event) {
                                                if (event == Snackbar.Callback.DISMISS_EVENT_TIMEOUT) {
                                                    if (!hashMap.isEmpty ()) {

                                                        //TODO - CHECK FOR CODE ONCE AGAIN
                                                        FirebaseDatabase.getInstance ().getReference ().child ("chats").orderByKey ().equalTo (id).addListenerForSingleValueEvent (new ValueEventListener () {
                                                            @Override
                                                            public void onDataChange (@NonNull DataSnapshot snapshot) {
                                                                for (DataSnapshot Snapshot: snapshot.getChildren()) {
                                                                    Snapshot.getRef().removeValue();
                                                                }
                                                            }

                                                            @Override
                                                            public void onCancelled (@NonNull DatabaseError error) {

                                                            }
                                                        });
                                                    }
                                                }
                                            }

                                            @Override
                                            public void onShown (Snackbar snackbar) {
                                            }
                                        });

                                        //((UserAdapter.ViewHolder) viewHolder).viewBackground.setVisibility (View.GONE);

                                        readUsers ();
                                    }
                                })
                                .setNegativeButton ("No", new DialogInterface.OnClickListener () {
                                    @Override
                                    public void onClick (DialogInterface dialog, int which) {

                                        ((UserAdapter.ViewHolder) viewHolder).viewBackground.setVisibility (View.GONE);

                                        readUsers ();
                                    }
                                })
                                .setCancelable (false).show ();

                    }
                    else{
                        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder (ContextActivity.this)
                                .setTitle ("Are You Sure you want to un-friend "+contactsList.get (position).getName ()+" from your contacts?")
                                .setPositiveButton ("Yes", new DialogInterface.OnClickListener () {
                                    @Override
                                    public void onClick (DialogInterface dialog, int which) {
                                        DatabaseReference friendRef = FirebaseDatabase.getInstance ().getReference ().child (Constants.STATUS_FRIEND);
                                        String sender = FirebaseAuth.getInstance ().getCurrentUser ().getUid ();
                                        String receiver = contactsList.get (position).getUid ();
                                        friendRef.child (sender).child (receiver).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                                            @Override
                                            public void onComplete (@NonNull Task<Void> task) {
                                                if (task.isSuccessful ()) {
                                                    friendRef.child (receiver).child (sender).removeValue ().addOnCompleteListener (new OnCompleteListener<Void> () {
                                                        @Override
                                                        public void onComplete (@NonNull Task<Void> task) {
                                                            if (task.isSuccessful ()) {
                                                                Toast.makeText (ContextActivity.this, name + " removed from your Contacts", Toast.LENGTH_SHORT).show ();
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                        readUsers ();
                                    }
                                })
                                .setNegativeButton ("No", new DialogInterface.OnClickListener () {
                                    @Override
                                    public void onClick (DialogInterface dialog, int which) {
                                        readUsers ();
                                    }
                                })
                                .setCancelable (false).show ();
                    }
                }
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {

                Bitmap icon;

                if(actionState == ItemTouchHelper.ACTION_STATE_SWIPE){

                    View itemView = viewHolder.itemView;
                    float height = (float) itemView.getBottom() - (float) itemView.getTop();
                    float width = height / 3;

                    if(dX > 0){
                        p.setColor(Color.parseColor("#388E3C"));
                        RectF background = new RectF((float) itemView.getLeft(), (float) itemView.getTop(), dX,(float) itemView.getBottom());
                        c.drawRect(background,p);
                        icon=drawableToBitmap ((VectorDrawable)ResourcesCompat.getDrawable (getResources (),R.drawable.ic_remove_friend,null));
                        //icon = BitmapFactory.decodeResource(getResources(), R.drawable.ic_remove_friend);
                        RectF icon_dest = new RectF((float) itemView.getLeft() + width ,(float) itemView.getTop() + width,(float) itemView.getLeft()+ 2*width,(float)itemView.getBottom() - width);
                        if(icon!=null && !icon.isRecycled () && icon_dest!=null) {
                            Log.d("message icon",icon.toString ());
                            c.drawBitmap (icon, null, icon_dest, p);
                        }
                    } else {
                        p.setColor(Color.parseColor("#D32F2F"));
                        RectF background = new RectF((float) itemView.getRight() + dX, (float) itemView.getTop(),(float) itemView.getRight(), (float) itemView.getBottom());
                        c.drawRect(background,p);
                        icon=drawableToBitmap ((VectorDrawable)ResourcesCompat.getDrawable (getResources (),R.drawable.ic_delete_icon,null));
                      //  icon = BitmapFactory.decodeResource(getResources(), R.drawable.ic_delete_icon);
                        RectF icon_dest = new RectF((float) itemView.getRight() - 2*width ,(float) itemView.getTop() + width,(float) itemView.getRight() - width,(float)itemView.getBottom() - width);

                        if(icon!=null && !icon.isRecycled () && icon_dest!=null) {
                            Log.d("message icon",icon.toString ());
                            c.drawBitmap (icon, null, icon_dest, p);
                        }
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        };
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(myContactList);
    }

    public static Bitmap drawableToBitmap (Drawable drawable) {
        Bitmap bitmap = null;

        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if(bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }

        if(drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
        } else {
            bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    @Override
    protected void onStart () {
        super.onStart ();
        if(FirebaseAuth.getInstance ().getCurrentUser ()==null){
            finish ();
        }
    }
}