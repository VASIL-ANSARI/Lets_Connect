package com.example.videoconferrencingapp;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.github.barteksc.pdfviewer.PDFView;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MessageActivity extends AppCompatActivity {

    private ImageView profile_image;
    private ImageView backgroundImage;
    private String userId;
    String senderRoom,receiverRoom;
    private String downloadUrl;
    private String room=null;

    MessageAdapter messageAdapter;
    List<Chat> messages;
    RecyclerView recyclerView;
    private TextView username;

    FirebaseUser fUser;
    DatabaseReference reference;
    Intent intent;

    FirebaseDatabase database;
    Uri filePath;
    String mCurrentPhotoPath;

    ImageButton btn_send,share_btn;
    EditText text_send;
    private DatabaseReference userRef;
    final int REQUEST_FOR_IMAGE=20;
    final int REQUEST_FOR_CAMERA=30;
    final int REQUEST_FOR_VIDEO=40;
    final int REQUEST_FOR_DOCUMENTS=50;
    final int REQUEST_FOR_CONTACTS=60;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        messages=new ArrayList<> ();

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        userRef= FirebaseDatabase.getInstance().getReference().child("Background");

        Toolbar toolbar=findViewById(R.id.toolbar_message);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        backgroundImage=findViewById (R.id.backgroundViewChat);
        recyclerView=findViewById(R.id.recycler_view_message);
        share_btn=findViewById (R.id.shareDocuments);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);


        profile_image=findViewById(R.id.profile_image_message);
        username=findViewById(R.id.message_text);
        btn_send=findViewById(R.id.btn_send_message);
        text_send=findViewById(R.id.text_send_message);


        intent=getIntent();
        userId=intent.getStringExtra("userid");

        fUser= FirebaseAuth.getInstance().getCurrentUser();

        senderRoom=fUser.getUid ()+userId;
        receiverRoom=userId+fUser.getUid ();

        room=userId+fUser.getUid ();

        reference= FirebaseDatabase.getInstance().getReference("Users").child(userId);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Contacts contacts=snapshot.getValue(Contacts.class);
                contacts.setName((String)snapshot.child("Name").getValue());
                contacts.setStatus((String)snapshot.child("Status").getValue());
                username.setText(contacts.getName());
                if(contacts.getImage().equals("")){
                    profile_image.setImageResource(R.drawable.profile_image);
                }
                else{
                    Picasso.get().load(contacts.getImage()).into(profile_image);
                }

                Log.d("message class",fUser.getUid()+" "+userId+" "+contacts.getImage());

                messageAdapter=new MessageAdapter (MessageActivity.this,messages,contacts.getImage (),senderRoom,receiverRoom);
                recyclerView.setAdapter (messageAdapter);

                //readMessage(fUser.getUid(),userId,contacts.getImage());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        database=FirebaseDatabase.getInstance ();

        database.getReference ().child ("chats").child (senderRoom).child ("messages")
                .addValueEventListener (new ValueEventListener () {
                    @Override
                    public void onDataChange (@NonNull DataSnapshot snapshot) {
                        messages.clear ();
                        for(DataSnapshot snapshot1:snapshot.getChildren ()){
                            Chat message=snapshot1.getValue (Chat.class);
                            message.setMessageId (snapshot1.getKey ());
                            messages.add (message);
                        }

                        messageAdapter.notifyDataSetChanged ();
                    }

                    @Override
                    public void onCancelled (@NonNull DatabaseError error) {

                    }
                });

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg=text_send.getText().toString();
                if(!msg.equals(""))
                {
                    //add feelings
                    sendMessage(senderRoom,receiverRoom,msg,"text");
                }
                else
                {
                    Toast.makeText(MessageActivity.this,"Empty message cannot be send",Toast.LENGTH_SHORT).show();

                }
                text_send.setText("");
            }
        });

        share_btn.setOnClickListener (new View.OnClickListener () {

            @Override
            public void onClick (View v) {
                PopupMenu popupMenu=new PopupMenu (MessageActivity.this,share_btn);
                // Inflating popup menu from popup_menu.xml file
                popupMenu.getMenuInflater().inflate(R.menu.share_menu_items, popupMenu.getMenu());

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    popupMenu.setForceShowIcon (true);
                }
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Toast message on menu item clicked
                        //Toast.makeText(MessageActivity.this, "You Clicked " + menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                        switch (menuItem.getItemId ()){
                            case R.id.camera_menu_id:
                                take_photo_from_camera();
                                break;
                            case R.id.images_menu_id:
                                take_image_from_images();
                                break;
                            case R.id.videos_menu_id:
                                take_video_from_videos();
                                break;
                            case R.id.documents_menu_id:
                                take_documents();
                                break;
                            case R.id.contacts_menu_id:
                                upload_contacts();
                                break;
                        }
                        return true;
                    }
                });
                // Showing the popup menu
                popupMenu.show();
            }
        });


    }

    public void retrieveBackgroundImage(){


        DatabaseReference reference1= FirebaseDatabase.getInstance().getReference("Background");

        reference1.addValueEventListener (new ValueEventListener () {
            @Override
            public void onDataChange (@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snapshot1:snapshot.getChildren ())
                {
                    Log.d("message",snapshot.getValue ().toString ());
                    String setterFor=snapshot1.child("setterFor").getValue().toString();
                    String setter=snapshot1.child("setter").getValue().toString();
                    String bgImage=snapshot1.child("bgImage").getValue().toString();

                    if(setterFor.equals (userId) && setter.equals (FirebaseAuth.getInstance ().getCurrentUser ().getUid ()) && bgImage!=null)
                    {
                        Picasso.get().load(bgImage).placeholder(R.drawable.profile_image).into(backgroundImage);
                    }


                }
            }

            @Override
            public void onCancelled (@NonNull DatabaseError error) {

            }
        });
    }

    private void sendMessage(String senderRoom,String receiverRoom,String messages,String type)
    {
        Date date=new Date ();
        Chat message=new Chat(messages,fUser.getUid (),date.getTime (),type);

        String randomKey=database.getReference ().push ().getKey ();
        HashMap<String,Object> lastMsgObj=new HashMap<> ();
        if(type.equals ("text")) {
            lastMsgObj.put ("lastMsg", message.getMessage ());
        }
        else if(type.equals ("image")){
            lastMsgObj.put ("lastMsg","Image");
        }
        else if(type.equals ("video")){
            lastMsgObj.put ("lastMsg", "Video");
        }
        else if(type.equals ("pdf")){
            lastMsgObj.put ("lastMsg","PDF Document");
        }
        lastMsgObj.put ("lastMsgTime",date.getTime ());

        database.getReference ().child ("chats").child (senderRoom).updateChildren (lastMsgObj);
        database.getReference ().child ("chats").child (receiverRoom).updateChildren (lastMsgObj);

        database.getReference ().child ("chats").child (senderRoom).child ("messages").child (randomKey)
                .setValue (message).addOnSuccessListener (new OnSuccessListener<Void> () {
            @Override
            public void onSuccess (Void aVoid) {
                database.getReference ().child ("chats").child (receiverRoom).child ("messages").child (randomKey)
                        .setValue (message).addOnSuccessListener (new OnSuccessListener<Void> () {
                    @Override
                    public void onSuccess (Void aVoid) {

                    }
                });
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.change_bg:
                ChangeBackground();
                return true;
            case R.id.view_profile:
                //show user data-name,image,status...
                Intent intent=new Intent (MessageActivity.this,ViewProfileActivity.class);
                intent.putExtra ("uidInfo",userId);
                startActivity (intent);
                return true;

            case R.id.audio_btn_send_message:
                sendAudioMessage();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void ChangeBackground(){
        //change image from gallery...
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,1);
    }
    public void sendAudioMessage(){

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Need to speak");
        try {
            startActivityForResult(intent, 10);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    "Sorry your device is not supported",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult (int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult (requestCode, resultCode, data);

        if(requestCode==10){

            if(resultCode==RESULT_OK && data!=null){
                ArrayList<String> result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
//                Log.d("message",result.get(0)+"-"+result.get(1));
                text_send.setText (result.get (0));

            }
        }
        if(requestCode==1 && resultCode==RESULT_OK && data!=null)
        {
            Uri bgImage=data.getData ();
            backgroundImage.setImageURI(bgImage);
            if(bgImage!=null)
            {

                saveBackgroundInfo (bgImage);
            }
        }
        if (requestCode == REQUEST_FOR_CAMERA && resultCode == RESULT_OK) {
            CropImage.activity(filePath).setAspectRatio(1,1)
                    .start(MessageActivity.this);
        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            Uri resultUri = result.getUri();
            LayoutInflater inflater= LayoutInflater.from(this);
            View view=inflater.inflate(R.layout.imagealertdialog, null);
            ImageView image =view.findViewById (R.id.imageAlertDialog);
            image.setImageURI (resultUri);

            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this).
                            setMessage("You Selected this Image.").
                            setPositiveButton("Send", new DialogInterface.OnClickListener () {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    uploadFile (resultUri,REQUEST_FOR_CAMERA);
                                    dialog.dismiss();
                                }
                            }).setNegativeButton ("Cancel", new DialogInterface.OnClickListener () {
                        @Override
                        public void onClick (DialogInterface dialog, int which) {
                            dialog.dismiss ();
                        }
                    }).setView(view);
            builder.create().show();
        }

        if(requestCode==REQUEST_FOR_IMAGE && resultCode==RESULT_OK){
            Uri resultUri=data.getData();
            LayoutInflater inflater= LayoutInflater.from(this);
            View view=inflater.inflate(R.layout.imagealertdialog, null);
            ImageView image =view.findViewById (R.id.imageAlertDialog);
            image.setImageURI (resultUri);

            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this).
                            setMessage("You Selected this Image.").
                            setPositiveButton("Send", new DialogInterface.OnClickListener () {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    uploadFile (resultUri,REQUEST_FOR_CAMERA);
                                    dialog.dismiss ();

                                }
                            }).setNegativeButton ("Cancel", new DialogInterface.OnClickListener () {
                        @Override
                        public void onClick (DialogInterface dialog, int which) {
                            dialog.dismiss ();
                        }
                    }).setView(view);

            builder.create().show();


        }
        if(requestCode==REQUEST_FOR_VIDEO && resultCode==RESULT_OK){
            Uri resultUri=data.getData();
            Log.d("message video :",resultUri.toString ());

            LayoutInflater inflater= LayoutInflater.from(this);
            View view=inflater.inflate(R.layout.videoalertdialog, null);

            // create an object of media controller
            //MediaController mediaController = new MediaController (this);
            VideoView simpleVideoView = view.findViewById(R.id.videoAlertDialog);
            simpleVideoView.setVideoURI (resultUri);
            simpleVideoView.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick (View v) {
                    if(simpleVideoView.isPlaying ()){
                        simpleVideoView.pause ();
                    }
                    else{
                        simpleVideoView.start ();
                    }
                }
            });
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this).
                            setMessage("You Selected this Video.").
                            setPositiveButton("Send", new DialogInterface.OnClickListener () {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    uploadFile (resultUri,REQUEST_FOR_VIDEO);
                                    dialog.dismiss();
                                }
                            }).setNegativeButton ("Cancel", new DialogInterface.OnClickListener () {
                        @Override
                        public void onClick (DialogInterface dialog, int which) {
                            dialog.dismiss ();
                        }
                    }).setView(view);
            builder.create().show();


        }
        if(requestCode==REQUEST_FOR_DOCUMENTS && resultCode==RESULT_OK){
            Uri resultUri=data.getData();
            LayoutInflater inflater= LayoutInflater.from(this);
            View view=inflater.inflate(R.layout.pdfvieweractivity, null);

            PDFView pdfView = view.findViewById(R.id.pdfView);
            pdfView.fromUri (resultUri).swipeHorizontal (true).load ();
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this).
                            setMessage("You Selected this Document.").
                            setPositiveButton("Send", new DialogInterface.OnClickListener () {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    uploadFile (resultUri,REQUEST_FOR_DOCUMENTS);
                                    dialog.dismiss();
                                }
                            }).setNegativeButton ("Cancel", new DialogInterface.OnClickListener () {
                        @Override
                        public void onClick (DialogInterface dialog, int which) {
                            dialog.dismiss ();
                        }
                    }).setView(view);
            builder.create().show();
        }
        if(requestCode==REQUEST_FOR_CONTACTS && resultCode==RESULT_OK){
            Uri contactData = data.getData();
            Log.d("message contact :",contactData.toString ());
            Cursor c =  getContentResolver().query(contactData, null, null, null, null);
            if (c.moveToFirst()) {

                String phoneNumber="",emailAddress="";
                String name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                String contactId = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
                Log.d("message contacts: ",name+" "+contactId);
                //http://stackoverflow.com/questions/866769/how-to-call-android-contacts-list   our upvoted answer

                String hasPhone = c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                if ( hasPhone.equalsIgnoreCase("1"))
                    hasPhone = "true";
                else
                    hasPhone = "false" ;

                if (Boolean.parseBoolean(hasPhone))
                {
                    Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ contactId,null, null);
                    while (phones.moveToNext())
                    {
                        phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }
                    phones.close();
                }

                String text_to_send="Name: "+name+"\n"+"Phone No: "+phoneNumber+"\n";
                text_send.setText (text_to_send);
                Log.d("message",text_to_send);
            }
            c.close();
        }

    }

    public void saveBackgroundInfo(Uri bgImage){
        StorageReference userProfileImaRef= FirebaseStorage.getInstance().getReference().child("Background Image");

        final StorageReference filePath=userProfileImaRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        final UploadTask uploadTask=filePath.putFile(bgImage);


        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>> () {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if(!task.isSuccessful())
                {
                    throw task.getException();
                }

                downloadUrl=filePath.getDownloadUrl().toString();

                return filePath.getDownloadUrl();
            }
        }).addOnCompleteListener(task -> {
            if (task.isSuccessful ()) {
                downloadUrl = task.getResult ().toString ();
                HashMap<String, Object> profileMap1 = new HashMap<> ();
                profileMap1.put ("setterFor", userId);
                profileMap1.put ("setter", FirebaseAuth.getInstance ().getCurrentUser ().getUid ());
                profileMap1.put ("bgImage", downloadUrl);
                FirebaseDatabase.getInstance().getReference().child("Background").child(room)
                        .updateChildren(profileMap1).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {

                           // Toast.makeText(MessageActivity.this,"Background Image updated",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp () {
        finish ();
        return super.onSupportNavigateUp ();
    }

    @Override
    protected void onStart () {
        super.onStart ();
        retrieveBackgroundImage();
    }

    private void take_photo_from_camera(){
        if (hasCamera()) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Ensure that there's a camera activity to handle the intent
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File

                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                            Uri.fromFile(photoFile));
                    filePath = Uri.fromFile(photoFile);
                    Log.e("Uri ", filePath + "");
                    startActivityForResult(takePictureIntent, REQUEST_FOR_CAMERA);
                }
            }

        }
    }

    // create image file method used in above function
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat ("yyyyMMdd_HHmmss").format(new Date ());
        String imageFileName = "JPEG_" + timeStamp + "_";
        String storageDir = Environment.getExternalStorageDirectory() + "/picupload";
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        Log.e("photo path = " , mCurrentPhotoPath);

        return image;
    }

    // to check whether camera is present or not
    private boolean hasCamera()
    {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

    private void take_image_from_images(){
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUEST_FOR_IMAGE);
    }

    private void take_video_from_videos(){
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("video/*");
        startActivityForResult(galleryIntent,REQUEST_FOR_VIDEO);

    }
    private void take_documents(){
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("*/*");
        startActivityForResult(galleryIntent,REQUEST_FOR_DOCUMENTS);
    }
    private void upload_contacts(){

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED) {
            ;
        } else {
            requestLocationPermission();
        }

        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent, REQUEST_FOR_CONTACTS);
    }

    //this method will upload the file
    private void uploadFile(Uri imageUri,Integer type) {

        //Log.d("message",type.toString ()+" "+filePath.toString ());
        //if there is a file to upload
        if (imageUri != null) {
            //displaying a progress dialog while upload is going on
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading");
            progressDialog.show();


            final StorageReference filePath=FirebaseStorage.getInstance ().getReference ().child ("SharedDocuments").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child (imageUri.toString ());

            final UploadTask uploadTask=filePath.putFile(imageUri);

            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if(!task.isSuccessful())
                    {
                        throw task.getException();
                    }

                    downloadUrl=filePath.getDownloadUrl().toString();

                    return filePath.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                                                               @Override
                                                               public void onComplete (@NonNull Task<Uri> task) {
                                                                   if (task.isSuccessful ()) {
                                                                       downloadUrl = task.getResult ().toString ();

                                                                       progressDialog.dismiss ();

                                                                       Toast.makeText(getApplicationContext(), "File Uploaded ", Toast.LENGTH_LONG).show();
                                                                       if(type==REQUEST_FOR_CAMERA || type==REQUEST_FOR_IMAGE){
                                                                           sendMessage (senderRoom, receiverRoom, downloadUrl,"image");
                                                                       }
                                                                       if(type==REQUEST_FOR_VIDEO){
                                                                           sendMessage (senderRoom, receiverRoom, downloadUrl,"video");
                                                                       }
                                                                       if(type==REQUEST_FOR_DOCUMENTS){
                                                                           sendMessage (senderRoom, receiverRoom,downloadUrl,"pdf");
                                                                       }

                                                                   }
                                                               }
                                                           });
        }
        //if there is not any file
        else {
            //you can display an error toast
        }
    }

    protected void requestLocationPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                android.Manifest.permission.READ_CONTACTS)) {
            // show UI part if you want here to show some rationale !!!

        } else {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_CONTACTS},
                    79);
        }

    }

    @Override
    public void onRequestPermissionsResult (int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 79:{
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    ;

                } else {

                    Toast.makeText (MessageActivity.this,"Permission denied ",Toast.LENGTH_SHORT).show ();
                }
                return;
            }
        }
    }
}