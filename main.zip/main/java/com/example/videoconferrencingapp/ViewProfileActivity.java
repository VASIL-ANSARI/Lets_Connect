package com.example.videoconferrencingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.WriterException;
import com.squareup.picasso.Picasso;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;
import de.hdodenhof.circleimageview.CircleImageView;

public class ViewProfileActivity extends AppCompatActivity {

    private String userId;
    private TextView username;
    private CircleImageView profile_image;
    private TextView status;
    private ImageView qrCodeIV;
    QRGEncoder qrgEncoder;
    Button imageButton;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_view_profile);
        Intent intent=getIntent ();
        userId= intent.getStringExtra ("uidInfo");
        username=findViewById (R.id.NameIDInfo);
        status=findViewById (R.id.StatusIDInfo);
        profile_image=findViewById (R.id.profileImageID);
        qrCodeIV=findViewById (R.id.idIVQrcode);
        imageButton=findViewById (R.id.qrCodeShare);

        imageButton.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View v) {
                Intent intent = new Intent(ViewProfileActivity.this, ScanActivity.class);
                startActivity(intent);
            }
        });

        if(userId!=null){
            Log.d("message",userId);
        }

        //read user data

        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Users").child(userId);

        reference.addValueEventListener(new ValueEventListener () {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Contacts contacts=snapshot.getValue(Contacts.class);
                username.setText(contacts.getName());
                status.setText (contacts.getStatus ());
                if(contacts.getImage().equals("")){
                    profile_image.setImageResource(R.drawable.profile_image);
                }
                else{
                    Picasso.get().load(contacts.getImage()).into(profile_image);
                }

                //readMessage(fUser.getUid(),userId,contacts.getImage());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        WindowManager windowManager=(WindowManager)getSystemService (WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        Point point = new Point ();
        display.getSize (point);

        int width = point.x;
        int height = point.y;
        int dimen = width < height ? width : height;
        dimen = dimen * 3 / 4;

        qrgEncoder=new QRGEncoder (userId, null, QRGContents.Type.TEXT, dimen);

        try {
            // getting our qrcode in the form of bitmap.
            Bitmap bitmap = qrgEncoder.encodeAsBitmap();
            qrCodeIV.setImageBitmap(bitmap);
            //Toast.makeText (ViewProfileActivity.this,"QR Code Generated",Toast.LENGTH_SHORT).show ();
        } catch (WriterException e) {
            // this method is called for
            // exception handling.
            Log.e("Tag", e.toString());
        }

    }

    private void shareIt() {
            //sharing implementation here
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Message From "+ FirebaseAuth.getInstance ().getCurrentUser ().getPhoneNumber ()+" via VideoChat App");
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Name: "+username+"\n"+"Status: "+status+"\n");
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }


}